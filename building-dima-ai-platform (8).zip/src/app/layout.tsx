import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Dima'AI — O'zbek tilidagi bepul AI platforma",
  description:
    "Dima'AI: o'zbek tilida suhbatlashadigan 3 ta AI chat va bepul rasm yaratish. Dima Start — bepul, Dima Pro va Dima Turbo — Premium.",
  keywords: ["Dima AI", "o'zbek AI", "sun'iy intellekt", "chatgpt o'zbek", "rasm yaratish"],
};

export const viewport: Viewport = {
  themeColor: "#070709",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="uz">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Unbounded:wght@500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="noise bg-ink-950 font-sans text-white antialiased">
        {children}
      </body>
    </html>
  );
}
