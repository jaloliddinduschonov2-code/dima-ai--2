import AppShell from "@/components/app-shell";

type View = "chat" | "image" | "slides" | "report" | "pricing" | "admin";
const VIEWS: View[] = ["chat", "image", "slides", "report", "pricing", "admin"];

export default async function AppPage({
  searchParams,
}: {
  searchParams: Promise<{ view?: string }>;
}) {
  const { view } = await searchParams;
  const initialView = VIEWS.includes(view as View) ? (view as View) : "chat";
  return <AppShell initialView={initialView} />;
}
