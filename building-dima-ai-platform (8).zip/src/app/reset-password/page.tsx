"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { CheckCircle2, KeyRound, Loader2, Lock, XCircle } from "lucide-react";

function ResetForm() {
  const params = useSearchParams();
  const token = params.get("token") ?? "";
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit() {
    setError(null);
    if (password.length < 8) return setError("Parol kamida 8 ta belgi bo'lsin");
    if (password !== confirm) return setError("Ikki parol bir xil emas");
    setBusy(true);
    try {
      const res = await fetch("/api/auth/reset", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, password }),
      });
      const data = await res.json();
      if (!res.ok) setError(data.error ?? "Parolni yangilab bo'lmadi");
      else setDone(true);
    } catch {
      setError("Internet xatosi. Qayta urinib ko'ring.");
    }
    setBusy(false);
  }

  return (
    <main className="flex min-h-dvh items-center justify-center bg-ink-950 px-4 py-12">
      <div className="glass w-full max-w-md rounded-3xl bg-ink-900/90 p-6 shadow-2xl sm:p-8">
        {done ? (
          <div className="text-center">
            <CheckCircle2 className="mx-auto h-14 w-14 text-emerald-400" />
            <h1 className="mt-4 font-display text-xl font-bold">Parol yangilandi</h1>
            <p className="mt-2 text-sm text-white/50">Endi yangi parolingiz bilan kirishingiz mumkin.</p>
            <Link href="/app" className="mt-6 inline-flex rounded-xl bg-gradient-to-br from-gold-300 to-gold-600 px-6 py-3 font-bold text-ink-950">
              Kirish sahifasiga o'tish
            </Link>
          </div>
        ) : !token ? (
          <div className="text-center">
            <XCircle className="mx-auto h-14 w-14 text-red-300" />
            <h1 className="mt-4 font-display text-xl font-bold">Havola noto'g'ri</h1>
            <Link href="/app" className="mt-5 inline-block text-sm font-bold text-gold-300">Ilovaga qaytish</Link>
          </div>
        ) : (
          <>
            <div className="mb-6 flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gold-400/10 text-gold-300"><KeyRound className="h-6 w-6" /></div>
              <div>
                <h1 className="font-display text-xl font-bold">Yangi parol</h1>
                <p className="text-xs text-white/45">Kamida 8 ta belgi kiriting</p>
              </div>
            </div>
            <div className="space-y-3">
              {[{ value: password, set: setPassword, placeholder: "Yangi parol" }, { value: confirm, set: setConfirm, placeholder: "Parolni takrorlang" }].map((f) => (
                <div key={f.placeholder} className="flex items-center gap-2.5 rounded-xl border border-white/10 bg-black/30 px-3.5 py-3 focus-within:border-gold-400/50">
                  <Lock className="h-4 w-4 text-white/35" />
                  <input type="password" value={f.value} onChange={(e) => f.set(e.target.value)} placeholder={f.placeholder} className="w-full bg-transparent text-sm text-white placeholder:text-white/30 focus:outline-none" />
                </div>
              ))}
            </div>
            {error && <p className="mt-3 rounded-lg border border-red-400/30 bg-red-500/10 px-3 py-2 text-xs text-red-200">{error}</p>}
            <button onClick={submit} disabled={busy} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-gold-300 to-gold-600 px-4 py-3 font-display text-sm font-bold text-ink-950 disabled:opacity-50">
              {busy && <Loader2 className="h-4 w-4 animate-spin" />} Parolni yangilash
            </button>
          </>
        )}
      </div>
    </main>
  );
}

export default function ResetPasswordPage() {
  return <Suspense fallback={<main className="min-h-dvh bg-ink-950" />}><ResetForm /></Suspense>;
}
