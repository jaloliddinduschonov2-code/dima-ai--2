import { NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { users, walletTransactions } from "@/db/schema";
import { getAdminUsers, requireAdmin } from "@/lib/admin";
import { isAdminEmail } from "@/lib/auth";

export async function GET() {
  try {
    await requireAdmin();
  } catch (e) {
    return e as Response;
  }
  const list = await getAdminUsers();
  return NextResponse.json({ users: list });
}

export async function PATCH(req: Request) {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (e) {
    return e as Response;
  }

  let body: {
    id?: string;
    plan?: string;
    role?: string;
    balanceDelta?: number;
    note?: string;
  };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Noto'g'ri so'rov" }, { status: 400 });
  }

  if (!body.id) {
    return NextResponse.json({ error: "Foydalanuvchi ID kerak" }, { status: 400 });
  }

  const [target] = await db.select().from(users).where(eq(users.id, body.id)).limit(1);
  if (!target) return NextResponse.json({ error: "Foydalanuvchi topilmadi" }, { status: 404 });

  const patch: Partial<{ plan: string; role: string }> = {};
  if (body.plan && ["start", "pro", "turbo"].includes(body.plan)) patch.plan = body.plan;
  if (body.role && ["user", "admin"].includes(body.role)) patch.role = body.role;

  if (isAdminEmail(target.email) && patch.role === "user") {
    return NextResponse.json(
      { error: "Asosiy admin rolini o'zgartirib bo'lmaydi" },
      { status: 400 },
    );
  }

  const delta = Number.isInteger(body.balanceDelta) ? Number(body.balanceDelta) : 0;
  if (Math.abs(delta) > 100_000_000) {
    return NextResponse.json({ error: "Bir martalik summa juda katta" }, { status: 400 });
  }
  if (delta < 0 && target.balanceSoms + delta < 0) {
    return NextResponse.json({ error: "Balansni noldan pastga tushirib bo'lmaydi" }, { status: 400 });
  }

  if (Object.keys(patch).length === 0 && delta === 0) {
    return NextResponse.json({ error: "Yangilanish yo'q" }, { status: 400 });
  }

  await db.transaction(async (tx) => {
    if (Object.keys(patch).length > 0) {
      await tx.update(users).set(patch).where(eq(users.id, body.id!));
    }
    if (delta !== 0) {
      await tx
        .update(users)
        .set({ balanceSoms: sql`${users.balanceSoms} + ${delta}` })
        .where(eq(users.id, body.id!));
      await tx.insert(walletTransactions).values({
        userId: body.id!,
        adminId: admin.id,
        amountSoms: delta,
        note: (body.note ?? "Admin tomonidan balans o'zgarishi").slice(0, 255),
      });
    }
  });

  const [updated] = await db
    .select({ balanceSoms: users.balanceSoms, plan: users.plan })
    .from(users)
    .where(eq(users.id, body.id))
    .limit(1);

  return NextResponse.json({ ok: true, user: updated });
}
