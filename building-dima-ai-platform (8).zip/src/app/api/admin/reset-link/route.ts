import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { requireAdmin } from "@/lib/admin";
import { createPasswordResetToken } from "@/lib/password-reset";

export async function POST(req: Request) {
  try {
    await requireAdmin();
  } catch (e) {
    return e as Response;
  }

  let body: { id?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Noto'g'ri so'rov" }, { status: 400 });
  }
  if (!body.id) return NextResponse.json({ error: "ID kerak" }, { status: 400 });

  const [user] = await db.select().from(users).where(eq(users.id, body.id)).limit(1);
  if (!user) return NextResponse.json({ error: "Foydalanuvchi topilmadi" }, { status: 404 });

  const { token, expiresAt } = await createPasswordResetToken(user.id);
  const origin = new URL(req.url).origin;
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || origin;
  return NextResponse.json({
    resetUrl: `${siteUrl}/reset-password?token=${token}`,
    expiresAt: expiresAt.toISOString(),
    email: user.email,
  });
}
