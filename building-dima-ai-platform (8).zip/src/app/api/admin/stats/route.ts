import { NextResponse } from "next/server";
import { getAdminStats, requireAdmin } from "@/lib/admin";

export async function GET() {
  try {
    await requireAdmin();
  } catch (e) {
    return e as Response;
  }
  const stats = await getAdminStats();
  return NextResponse.json(stats);
}
