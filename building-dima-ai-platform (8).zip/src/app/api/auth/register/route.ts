import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, hashPassword, isAdminEmail, publicUser } from "@/lib/auth";

export async function POST(req: Request) {
  let body: { email?: string; password?: string; name?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Noto'g'ri so'rov" }, { status: 400 });
  }

  const email = (body.email ?? "").trim().toLowerCase();
  const password = body.password ?? "";
  const name = (body.name ?? "").trim();

  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    return NextResponse.json(
      { error: "Email manzil noto'g'ri yozilgan" },
      { status: 400 },
    );
  }
  if (password.length < 6) {
    return NextResponse.json(
      { error: "Parol kamida 6 ta belgidan iborat bo'lsin" },
      { status: 400 },
    );
  }

  try {
    const existing = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.email, email))
      .limit(1);
    if (existing.length > 0) {
      return NextResponse.json(
        { error: "Bu email allaqachon ro'yxatdan o'tgan. Kirishni sinang." },
        { status: 409 },
      );
    }

    // Faqat maxsus admin email'lari admin rolini oladi
    const role = isAdminEmail(email) ? "admin" : "user";

    const [user] = await db
      .insert(users)
      .values({
        email,
        name: name || email.split("@")[0],
        passwordHash: hashPassword(password),
        role,
        plan: "start",
      })
      .returning();

    await createSession(user.id);
    return NextResponse.json({ user: publicUser(user) });
  } catch {
    return NextResponse.json(
      { error: "Server xatosi. Birozdan keyin qayta urining." },
      { status: 500 },
    );
  }
}
