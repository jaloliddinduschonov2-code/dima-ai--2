import { NextResponse } from "next/server";
import { and, eq, gt, isNull } from "drizzle-orm";
import { db } from "@/db";
import { passwordResetTokens, sessions, users } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { hashResetToken } from "@/lib/password-reset";

export async function POST(req: Request) {
  let body: { token?: string; password?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Noto'g'ri so'rov" }, { status: 400 });
  }

  const token = body.token ?? "";
  const password = body.password ?? "";
  if (token.length < 40) return NextResponse.json({ error: "Havola noto'g'ri" }, { status: 400 });
  if (password.length < 8) {
    return NextResponse.json({ error: "Yangi parol kamida 8 ta belgi bo'lsin" }, { status: 400 });
  }

  const tokenHash = hashResetToken(token);
  const [row] = await db
    .select()
    .from(passwordResetTokens)
    .where(
      and(
        eq(passwordResetTokens.tokenHash, tokenHash),
        gt(passwordResetTokens.expiresAt, new Date()),
        isNull(passwordResetTokens.usedAt),
      ),
    )
    .limit(1);

  if (!row) {
    return NextResponse.json(
      { error: "Havola eskirgan yoki avval ishlatilgan" },
      { status: 400 },
    );
  }

  await db.transaction(async (tx) => {
    await tx
      .update(users)
      .set({ passwordHash: hashPassword(password) })
      .where(eq(users.id, row.userId));
    await tx
      .update(passwordResetTokens)
      .set({ usedAt: new Date() })
      .where(eq(passwordResetTokens.id, row.id));
    // Xavfsizlik: barcha eski sessiyalarni yopamiz.
    await tx.delete(sessions).where(eq(sessions.userId, row.userId));
  });

  return NextResponse.json({ ok: true });
}
