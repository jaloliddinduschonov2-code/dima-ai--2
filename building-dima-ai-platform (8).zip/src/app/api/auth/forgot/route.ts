import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createPasswordResetToken, sendResetEmail } from "@/lib/password-reset";

export async function POST(req: Request) {
  let body: { email?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Noto'g'ri so'rov" }, { status: 400 });
  }

  const email = (body.email ?? "").trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    return NextResponse.json({ error: "Email noto'g'ri yozilgan" }, { status: 400 });
  }

  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);

  // Email bor-yo'qligini begonalarga bildirmaymiz.
  let delivered = false;
  if (user) {
    const { token } = await createPasswordResetToken(user.id);
    const origin = new URL(req.url).origin;
    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || origin;
    const resetUrl = `${siteUrl}/reset-password?token=${token}`;
    delivered = await sendResetEmail({ to: user.email, name: user.name, resetUrl });
  }

  return NextResponse.json({
    ok: true,
    delivered,
    message: delivered
      ? "Parolni tiklash havolasi emailingizga yuborildi. Spam papkasini ham tekshiring."
      : "Agar hisob mavjud bo'lsa, tiklash so'rovi qabul qilindi. Email xizmati ulanmagan bo'lsa, Google bilan kiring yoki @Dima_ai_admin ga yozing.",
  });
}
