import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import {
  createSession,
  hashPassword,
  isAdminEmail,
} from "@/lib/auth";
import { verifyGoogleCode, googleIsConfigured } from "@/lib/google-auth";
import { SITE } from "@/lib/public-env";

function randomSecurePassword() {
  return `google_${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const code = url.searchParams.get("code");
  const stateParam = url.searchParams.get("state") ?? "";
  const errorParam = url.searchParams.get("error");

  const cookieStore = await cookies();
  const cookieState = cookieStore.get("google_oauth_state")?.value ?? "";
  cookieStore.delete("google_oauth_state");

  const redirectBase =
    process.env.NODE_ENV === "production"
      ? SITE.url
      : url.origin;

  const fallbackRedirect = `${redirectBase}/app?auth=google-error`;

  if (errorParam || !code) {
    return NextResponse.redirect(fallbackRedirect);
  }
  if (stateParam !== cookieState) {
    return NextResponse.redirect(`${redirectBase}/app?auth=state-error`);
  }

  // State oxirida redirect yo'li saqlangan
  const redirectTo = stateParam.split("|")[1] || "/app";

  if (!googleIsConfigured()) {
    return NextResponse.redirect(`${redirectBase}/app?auth=not-configured`);
  }

  try {
    const redirectUri = `${redirectBase}/api/auth/callback/google`;
    const info = await verifyGoogleCode(code, redirectUri);
    if (!info.emailVerified) {
      return NextResponse.redirect(`${redirectBase}/app?auth=email-unverified`);
    }

    const email = info.email;
    const existing = await db
      .select()
      .from(users)
      .where(eq(users.email, email))
      .limit(1);

    let user;
    if (existing.length === 0) {
      const role = isAdminEmail(email) ? "admin" : "user";
      const [created] = await db
        .insert(users)
        .values({
          email,
          name: info.name ?? email.split("@")[0],
          passwordHash: hashPassword(randomSecurePassword()),
          role,
          plan: "start",
        })
        .returning();
      user = created;
    } else {
      user = existing[0];
      // Agar email admin ro'yxatiga kirdi-yu, rol user bo'lsa — avtomatik ko'taramiz
      if (isAdminEmail(email) && user.role !== "admin") {
        await db
          .update(users)
          .set({ role: "admin" })
          .where(eq(users.id, user.id));
        user = { ...user, role: "admin" };
      }
    }

    await createSession(user.id);
    return NextResponse.redirect(
      `${redirectBase}${redirectTo.startsWith("/") ? redirectTo : "/app"}`,
    );
  } catch (e) {
    console.error("Google callback error:", e);
    return NextResponse.redirect(fallbackRedirect);
  }
}
