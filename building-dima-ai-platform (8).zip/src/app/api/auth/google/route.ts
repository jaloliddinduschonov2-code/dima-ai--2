import { NextResponse } from "next/server";
import { randomBytes } from "crypto";
import { cookies } from "next/headers";
import { getGoogleAuthUrl, googleIsConfigured } from "@/lib/google-auth";
import { SITE } from "@/lib/public-env";

export async function GET(req: Request) {
  if (!googleIsConfigured()) {
    return NextResponse.json(
      {
        error:
          "Google login hali sozlanmagan. Administrator Google Cloud'dan Client ID/Secret olib, Vercel Environment Variables'ga qo'shishi kerak.",
        code: "GOOGLE_NOT_CONFIGURED",
      },
      { status: 503 },
    );
  }

  const url = new URL(req.url);
  const redirect = url.searchParams.get("redirect") || "/app";
  const state = randomBytes(16).toString("hex") + "|" + redirect;

  const cookieStore = await cookies();
  cookieStore.set("google_oauth_state", state, {
    httpOnly: true,
    sameSite: "lax",
    maxAge: 60 * 10,
    secure: process.env.NODE_ENV === "production",
    path: "/",
  });

  const redirectUri =
    process.env.NEXT_PUBLIC_SITE_URL
      ? `${SITE.url}/api/auth/callback/google`
      : `${url.origin}/api/auth/callback/google`;

  const authUrl = getGoogleAuthUrl(redirectUri, state);
  return NextResponse.redirect(authUrl, { status: 302 });
}
