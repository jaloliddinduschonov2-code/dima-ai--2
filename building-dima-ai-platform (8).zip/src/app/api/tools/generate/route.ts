import { NextResponse } from "next/server";
import { db } from "@/db";
import { documentGenerations } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export const maxDuration = 120;

type Kind = "slides" | "report";

function extractJson(text: string) {
  const clean = text.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
  const start = clean.indexOf("{");
  const end = clean.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("JSON topilmadi");
  return JSON.parse(clean.slice(start, end + 1));
}

function systemFor(kind: Kind, count: number, language: string) {
  if (kind === "slides") {
    return `Siz professional taqdimot yaratuvchi AI'siz. Faqat sof JSON qaytaring, markdown yo'q. Til: ${language}. JSON shakli: {"title":"...","subtitle":"...","slides":[{"title":"...","bullets":["...","..."],"speakerNotes":"..."}]}. Aynan ${count} ta slayd bo'lsin. Birinchi slayd muqova, oxirgisi xulosa. Har slaydda 3-5 qisqa bullet. Faktlarni to'qimang.`;
  }
  return `Siz akademik referat yozuvchi AI'siz. Faqat sof JSON qaytaring, markdown yo'q. Til: ${language}. JSON shakli: {"title":"...","introduction":["paragraf"],"sections":[{"heading":"...","paragraphs":["...","..."]}],"conclusion":["..."],"sources":["..."]}. ${count} ta asosiy bo'lim bo'lsin. Matn batafsil, tushunarli, akademik va original bo'lsin. Manbalarni ishonchli umumiy formatda yozing, mavjud bo'lmagan URL to'qimang.`;
}

async function generateWithPollinations(messages: Array<{ role: string; content: string }>) {
  const waits = [0, 8_000, 16_000];
  for (let i = 0; i < waits.length; i++) {
    if (waits[i]) await new Promise((r) => setTimeout(r, waits[i]));
    try {
      const res = await fetch("https://text.pollinations.ai/openai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "openai",
          stream: false,
          temperature: 0.55,
          max_tokens: 6000,
          messages,
        }),
      });
      if (!res.ok) continue;
      const data = await res.json();
      const text = data?.choices?.[0]?.message?.content;
      if (typeof text === "string" && text.length > 20) return text;
    } catch {
      // keyingi urinish
    }
  }
  return null;
}

export async function POST(req: Request) {
  let body: { kind?: Kind; topic?: string; count?: number; language?: string; details?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Noto'g'ri so'rov" }, { status: 400 });
  }

  const kind: Kind = body.kind === "report" ? "report" : "slides";
  const topic = (body.topic ?? "").trim();
  const details = (body.details ?? "").trim().slice(0, 2000);
  const language = (body.language ?? "O'zbek tili").slice(0, 40);
  const count = Math.max(kind === "slides" ? 5 : 2, Math.min(kind === "slides" ? 20 : 8, Number(body.count) || (kind === "slides" ? 10 : 4)));

  if (topic.length < 3 || topic.length > 300) {
    return NextResponse.json({ error: "Mavzuni 3–300 belgi oralig'ida yozing" }, { status: 400 });
  }

  const text = await generateWithPollinations([
    { role: "system", content: systemFor(kind, count, language) },
    { role: "user", content: `Mavzu: ${topic}${details ? `\nQo'shimcha talab: ${details}` : ""}` },
  ]);

  if (!text) {
    return NextResponse.json(
      { error: "Bepul AI hozir band. 20 soniyadan keyin qayta urining." },
      { status: 503 },
    );
  }

  let content: unknown;
  try {
    content = extractJson(text);
  } catch {
    return NextResponse.json(
      { error: "AI javobi tayyor, lekin formatlashda xato. Qayta yaratishni bosing." },
      { status: 502 },
    );
  }

  try {
    const user = await getCurrentUser();
    await db.insert(documentGenerations).values({
      userId: user?.id ?? null,
      kind,
      topic,
      content: JSON.stringify(content),
    });
  } catch {
    // Tarixga yozilmasa ham natijani qaytaramiz.
  }

  return NextResponse.json({ kind, topic, content, provider: "pollinations-free" });
}
