import { NextResponse } from "next/server";
import { db } from "@/db";
import { imageGenerations } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export const maxDuration = 30;

/**
 * 1-QADAM: Rasm yaratish — ISHLAYDI.
 * Pollinations.ai — to'liq bepul rasm xizmati: API kalit SHART EMAS,
 * Gemini 503 va Cloudflare 401 muammolari bu yerda yo'q.
 */

type Quality = "hd" | "2k" | "4k";

// Sifat darajalari: hd (tez), 2k, 4k (haqiqiy 3840px — sekinroq)
const SIZES: Record<string, Record<Quality, { width: number; height: number }>> = {
  "1:1": {
    hd: { width: 1024, height: 1024 },
    "2k": { width: 1536, height: 1536 },
    "4k": { width: 2048, height: 2048 },
  },
  "16:9": {
    hd: { width: 1344, height: 768 },
    "2k": { width: 1920, height: 1088 },
    "4k": { width: 3840, height: 2160 },
  },
  "9:16": {
    hd: { width: 768, height: 1344 },
    "2k": { width: 1088, height: 1920 },
    "4k": { width: 2160, height: 3840 },
  },
};

const STYLES: Record<string, string> = {
  none: "",
  realistic: ", ultra realistic photo, 8k, highly detailed, cinematic lighting",
  anime: ", anime style, vibrant colors, detailed illustration",
  render3d: ", 3d render, octane render, soft studio lighting, high detail",
  cyberpunk: ", cyberpunk style, neon lights, futuristic city, rain, moody",
  watercolor: ", watercolor painting, soft washes, artistic, hand painted",
  logo: ", minimal vector logo, flat design, clean white background",
  fantasy: ", epic fantasy digital art, dramatic lighting, intricate details",
};

export async function POST(req: Request) {
  let body: { prompt?: string; style?: string; ratio?: string; quality?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Noto'g'ri so'rov" }, { status: 400 });
  }

  const prompt = (body.prompt ?? "").trim();
  if (prompt.length < 3) {
    return NextResponse.json(
      { error: "Rasm tavsifini yozing (kamida 3 ta belgi)" },
      { status: 400 },
    );
  }
  if (prompt.length > 600) {
    return NextResponse.json(
      { error: "Tavsif juda uzun (maksimum 600 belgi)" },
      { status: 400 },
    );
  }

  const style = body.style && body.style in STYLES ? body.style : "none";
  const ratio = body.ratio && body.ratio in SIZES ? body.ratio : "1:1";
  const quality: Quality =
    body.quality === "2k" || body.quality === "4k" ? (body.quality as Quality) : "hd";
  const { width, height } = SIZES[ratio][quality];
  const seed = Math.floor(Math.random() * 1_000_000);

  // enhance=true — o'zbekcha promptni avtomatik yaxshilaydi/tarjima qiladi
  const fullPrompt = `${prompt}${STYLES[style]}`;
  const url =
    `https://image.pollinations.ai/prompt/${encodeURIComponent(fullPrompt)}` +
    `?width=${width}&height=${height}&seed=${seed}` +
    `&model=flux&nologo=true&enhance=true&safe=true`;

  // Bazaga yozamiz — 2-qadamda (limitlar) shu sanaladi
  try {
    const user = await getCurrentUser();
    await db.insert(imageGenerations).values({
      userId: user?.id ?? null,
      prompt,
      style,
      ratio,
      quality,
      width,
      height,
      seed,
    });
  } catch {
    // yozish xatosi rasm yaratishga to'sqinlik qilmasin
  }

  return NextResponse.json({
    url,
    seed,
    width,
    height,
    quality,
    provider: "pollinations",
  });
}
