import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { chatMessages, conversations } from "@/db/schema";
import { PROVIDERS, type ChatId, type ProviderId, type ProviderAttempt } from "@/lib/providers";

export const maxDuration = 120;

/**
 * Vizual nomlar foydalanuvchiga ko'rinadi, haqiqiy kalitlar faqat serverda:
 *  - GPT Astra 6     -> OpenAI (OPENAI_API_KEY)
 *  - Gemini Pro      -> Groq   (GROQ_API_KEY)
 *  - Claude Opus 5.5 -> Groq   (vision model — rasm ko'radi)
 *  - Har qanday kalit ishlamasa -> Pollinations (kalitsiz, bepul) avtomatik.
 */

const SYSTEM_BASE =
  "Siz Dima'AI platformasidagi AI yordamchisisiz. MUHIM QOIDA: har doim faqat o'zbek tilida (lotin yozuvida) javob bering. Javoblar aniq, amaliy va chiroyli tuzilgan bo'lsin. Agar foydalanuvchi rasm yuborsa — uni tasvirlab bering. Agar fayl yuborsa — mazmuni asosida javob bering.";

const TEMPLATE_PROMPTS: Record<string, string> = {
  referat:
    "\n\nHOZIRGI MAQSAD — foydalanuvchi bergan mavzu bo'yicha to'liq, akademik referat yozish. Tuzilish: 1) Kirish, 2) Asosiy qism (2-3 kichik bo'lim), 3) Xulosa, 4) Foydalanilgan adabiyotlar (3-5 ta). Hajmi ~800-1500 so'z.",
  slayd:
    "\n\nHOZIRGI MAQSAD — taqdimot uchun slaydlar matnini tayyorlash. Har bir slayd: 'Slayd N: {sarlavha}' + 3-5 bullet. Jami 8-12 slayd: muqova, mundarija, asosiy slaydlar, xulosa, rahmat. PowerPoint'ga nusxalashga tayyor o'zbekcha matn.",
};

type InboundAttachment = {
  kind: "image" | "file";
  filename: string;
  mimeType?: string;
  content: string; // image uchun data URL, file uchun matn
};

type ChatMessageIn = {
  role: "user" | "assistant";
  content: string;
  attachments?: InboundAttachment[];
};

type OutContent =
  | string
  | Array<
      | { type: "text"; text: string }
      | { type: "image_url"; image_url: { url: string } }
    >;

type OutMessage = { role: "user" | "assistant" | "system"; content: OutContent };

function parseInboundMessages(raw: ChatMessageIn[]): OutMessage[] {
  return raw.map((m) => {
    if (m.role === "assistant") {
      return { role: "assistant", content: m.content };
    }
    const images = (m.attachments ?? []).filter((a) => a.kind === "image");
    const files = (m.attachments ?? []).filter((a) => a.kind === "file");

    const parts: Exclude<OutContent, string> = [];
    let text = m.content ?? "";
    if (files.length > 0) {
      const blocks = files.map(
        (f) =>
          `\n\n[Yuklangan fayl: ${f.filename}]\n--- Fayl mazmuni boshi ---\n${f.content}\n--- Fayl mazmuni oxiri ---`,
      );
      text = (text + blocks.join("\n\n")).trim();
    }
    if (text) parts.push({ type: "text", text });

    for (const img of images) {
      const dataUrl = img.content.startsWith("data:")
        ? img.content
        : `data:${img.mimeType ?? "image/jpeg"};base64,${img.content}`;
      parts.push({ type: "image_url", image_url: { url: dataUrl } });
    }

    if (parts.length === 0) return { role: "user", content: "(bo'sh xabar)" };
    if (parts.length === 1 && parts[0].type === "text") {
      return { role: "user", content: parts[0].text };
    }
    return { role: "user", content: parts };
  });
}

function keyFor(provider: ProviderId): string | null {
  if (provider === "groq") return process.env.GROQ_API_KEY ?? null;
  if (provider === "openai") return process.env.OPENAI_API_KEY ?? null;
  return null; // pollinations — kalit shart emas
}

/** SSE (stream) ni talab qiladigan provayder chaqirig'i */
async function callStreaming(opts: {
  provider: Exclude<ProviderId, "pollinations">;
  model: string;
  temperature: number;
  maxTokens: number;
  messages: OutMessage[];
}): Promise<Response | null> {
  const key = keyFor(opts.provider);
  if (!key) return null;
  const endpoint =
    opts.provider === "groq"
      ? "https://api.groq.com/openai/v1/chat/completions"
      : "https://api.openai.com/v1/chat/completions";
  try {
    return await fetch(endpoint, {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: opts.model,
        stream: true,
        temperature: opts.temperature,
        max_tokens: opts.maxTokens,
        messages: opts.messages,
      }),
    });
  } catch {
    return null;
  }
}

/** Kalitsiz, bepul zaxira — Pollinations Text API (bir yo'la to'liq javob) */
async function callPollinations(opts: {
  model: string;
  temperature: number;
  maxTokens: number;
  messages: OutMessage[];
}): Promise<string | null> {
  const endpoint = "https://text.pollinations.ai/openai";
  const payload = () =>
    JSON.stringify({
      model: opts.model,
      stream: false,
      temperature: opts.temperature,
      max_tokens: opts.maxTokens,
      messages: opts.messages,
    });

  // Bepul tier so'rovlar orasida vaqt talab qiladi — sabr bilan 3 marta urinamiz
  const waits = [20000, 30000];
  for (let tryN = 0; tryN < 3; tryN++) {
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: payload(),
      });
      if (res.status === 429 || res.status === 503) {
        if (tryN < 2) await new Promise((r) => setTimeout(r, waits[tryN]));
        continue;
      }
      if (!res.ok) return null;
      const json = await res.json().catch(() => null);
      const text = json?.choices?.[0]?.message?.content;
      if (typeof text === "string" && text.length > 0) return text;
      return null;
    } catch {
      if (tryN < 2) await new Promise((r) => setTimeout(r, waits[tryN]));
    }
  }
  return null;
}

export async function POST(req: Request) {
  let body: {
    chat?: string;
    messages?: ChatMessageIn[];
    template?: "referat" | "slayd" | null;
    conversationId?: string | null;
  };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Noto'g'ri so'rov" }, { status: 400 });
  }

  const chatId = (body.chat ?? "gemini-pro") as ChatId;
  const def = PROVIDERS[chatId] ?? PROVIDERS["gemini-pro"];
  const user = await getCurrentUser().catch(() => null);

  const premiumOnly = chatId === "gpt-astra-6" || chatId === "claude-opus";
  const premiumAccess =
    user && (user.role === "admin" || user.plan === "pro" || user.plan === "turbo");
  if (premiumOnly && !premiumAccess) {
    return NextResponse.json(
      {
        error: user
          ? "Bu AI faqat Dima Pro va Dima Turbo a'zolari uchun. Premium rejaga o'ting."
          : "Bu AI Premium uchun. Avval hisobingizga kiring.",
        code: "PREMIUM_REQUIRED",
      },
      { status: 403 },
    );
  }

  const template =
    body.template === "referat" || body.template === "slayd" ? body.template : null;
  const systemPrompt = SYSTEM_BASE + (template ? TEMPLATE_PROMPTS[template] : "");

  const rawMessages = Array.isArray(body.messages) ? body.messages.slice(-10) : [];
  const outgoing = parseInboundMessages(rawMessages);

  const hasImages = outgoing.some(
    (m) => Array.isArray(m.content) && m.content.some((p) => p.type === "image_url"),
  );

  const payloadMessages: OutMessage[] = [
    { role: "system", content: systemPrompt },
    ...outgoing,
  ];

  // Urinishlar zanjiri: asosiy → zaxira(lar)
  const attempts: ProviderAttempt[] = [
    { provider: def.provider, model: def.model },
    ...(def.fallback ?? []),
  ];

  // Kalit yo'q provayderlarni (Groq/OpenAI) darhol o'tkazib yuborish —
  // sabr vaqtni tejaydi
  let upstreamStream: Response | null = null;
  let plainReply: string | null = null;
  let lastStatus = 0;

  for (const attempt of attempts) {
    if (attempt.provider !== "pollinations" && !keyFor(attempt.provider)) {
      continue; // kalit saqlanmaguncha bu provayderni sinash keraksiz vaqt oldiradi
    }
    if (attempt.provider === "pollinations") {
      const text = await callPollinations({
        model: attempt.model,
        temperature: def.temperature,
        maxTokens: def.maxTokens,
        messages: payloadMessages,
      });
      if (text) {
        plainReply = text;
        break;
      }
      lastStatus = 503;
      continue;
    }

    // Groq/OpenAI — rasm bo'lsa Groq'da vision modelga almashtiramiz
    let model = attempt.model;
    if (attempt.provider === "groq" && hasImages) {
      model = "meta-llama/llama-4-scout-17b-16e-instruct";
    }
    const res = await callStreaming({
      provider: attempt.provider,
      model,
      temperature: def.temperature,
      maxTokens: def.maxTokens,
      messages: payloadMessages,
    });
    if (res && res.ok && res.body) {
      upstreamStream = res;
      break;
    }
    if (res) lastStatus = res.status;
    // xato bo'lsa — keyingi provayderga o'tadi
  }

  if (!upstreamStream && !plainReply) {
    const msg =
      lastStatus === 429
        ? "GPT Astra 6 vaqtincha to'xtadi (hisobda mablag' qolmagan). Birozdan keyin urinib ko'ring yoki boshqa rejimni tanlang."
        : "AI xizmatida vaqtinchalik nosozlik. Birozdan keyin qayta urinib ko'ring yoki boshqa rejimni tanlang.";
    return NextResponse.json({ error: msg }, { status: 502 });
  }

  // Tarix: yangi suhbat yaratish yoki mavjud suhbat egasini tekshirish.
  const lastUserMsg = rawMessages.findLast((m) => m.role === "user");
  let activeConversationId: string | null = null;
  if (user && lastUserMsg) {
    if (body.conversationId) {
      const [owned] = await db
        .select({ id: conversations.id })
        .from(conversations)
        .where(
          and(
            eq(conversations.id, body.conversationId),
            eq(conversations.userId, user.id),
          ),
        )
        .limit(1);
      activeConversationId = owned?.id ?? null;
    }

    if (!activeConversationId) {
      const title = (
        lastUserMsg.content ||
        lastUserMsg.attachments?.[0]?.filename ||
        "Yangi suhbat"
      )
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, 150);
      const [created] = await db
        .insert(conversations)
        .values({ userId: user.id, chatId, title: title || "Yangi suhbat" })
        .returning({ id: conversations.id });
      activeConversationId = created.id;
    }

    await db.insert(chatMessages).values({
      userId: user.id,
      conversationId: activeConversationId,
      chatId,
      role: "user",
      content: lastUserMsg.content || "(fayl yuborildi)",
      attachments: lastUserMsg.attachments?.length
        ? JSON.stringify(
            lastUserMsg.attachments.map((a) => ({ kind: a.kind, filename: a.filename })),
          )
        : null,
    });
    await db
      .update(conversations)
      .set({ updatedAt: new Date() })
      .where(eq(conversations.id, activeConversationId));
  }

  let assistantAcc = "";

  const textStream = new ReadableStream<string>({
    async start(controller) {
      // B) Pollinations — bir yo'la javob
      if (!upstreamStream && plainReply) {
        assistantAcc = plainReply;
        controller.enqueue(plainReply);
        controller.close();
        return;
      }

      // A) Groq/OpenAI — oqim bo'ylab javob
      const decoder = new TextDecoder();
      const reader = upstreamStream!.body!.getReader();
      let buffer = "";
      try {
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() ?? "";
          for (const line of lines) {
            const t = line.trim();
            if (!t.startsWith("data:")) continue;
            const data = t.slice(5).trim();
            if (data === "[DONE]") {
              controller.close();
              return;
            }
            try {
              const json = JSON.parse(data);
              const delta = json.choices?.[0]?.delta?.content;
              if (typeof delta === "string" && delta.length > 0) {
                assistantAcc += delta;
                controller.enqueue(delta);
              }
            } catch {
              /* yarim JSON qator */
            }
          }
        }
        controller.close();
      } catch {
        try {
          controller.close();
        } catch {
          /* yopiq */
        }
      }
    },
  });

  const encoder = new TextEncoder();
  const byteStream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const reader = textStream.getReader();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        controller.enqueue(encoder.encode(value));
      }
      controller.close();
      // AI javobini aynan shu suhbat tarixiga yozamiz.
      if (user && activeConversationId && assistantAcc) {
        db.insert(chatMessages)
          .values({
            userId: user.id,
            conversationId: activeConversationId,
            chatId,
            role: "assistant",
            content: assistantAcc,
          })
          .then(() =>
            db
              .update(conversations)
              .set({ updatedAt: new Date() })
              .where(eq(conversations.id, activeConversationId!)),
          )
          .catch(() => {});
      }
    },
  });

  return new Response(byteStream, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Chat": def.label,
      ...(activeConversationId ? { "X-Conversation-Id": activeConversationId } : {}),
    },
  });
}
