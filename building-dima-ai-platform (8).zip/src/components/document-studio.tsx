"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  Check,
  Copy,
  Download,
  FileText,
  Loader2,
  Presentation,
  Sparkles,
  Wand2,
} from "lucide-react";

type Kind = "slides" | "report";
type SlideDoc = {
  title: string;
  subtitle?: string;
  slides: Array<{ title: string; bullets: string[]; speakerNotes?: string }>;
};
type ReportDoc = {
  title: string;
  introduction: string[];
  sections: Array<{ heading: string; paragraphs: string[] }>;
  conclusion: string[];
  sources: string[];
};

const COLORS = {
  bg: "0B0B0F",
  panel: "15151D",
  gold: "F5C044",
  light: "FFF4D0",
  muted: "B7B7C2",
};

export default function DocumentStudio({ initialKind = "slides" }: { initialKind?: Kind }) {
  const [kind, setKind] = useState<Kind>(initialKind);
  const [topic, setTopic] = useState("");
  const [details, setDetails] = useState("");
  const [count, setCount] = useState(initialKind === "slides" ? 10 : 4);
  const [result, setResult] = useState<SlideDoc | ReportDoc | null>(null);
  const [busy, setBusy] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  function switchKind(next: Kind) {
    setKind(next);
    setCount(next === "slides" ? 10 : 4);
    setResult(null);
    setError(null);
  }

  async function generate() {
    if (topic.trim().length < 3 || busy) return;
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const res = await fetch("/api/tools/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind, topic, details, count, language: "O'zbek tili" }),
      });
      const data = await res.json();
      if (!res.ok) setError(data.error ?? "Yaratib bo'lmadi");
      else setResult(data.content);
    } catch {
      setError("Internet xatosi. Qayta urinib ko'ring.");
    }
    setBusy(false);
  }

  function asPlainText() {
    if (!result) return "";
    if (kind === "slides") {
      const d = result as SlideDoc;
      return [d.title, d.subtitle ?? "", ...d.slides.map((s, i) => `\nSLAYD ${i + 1}: ${s.title}\n${s.bullets.map((b) => `• ${b}`).join("\n")}`)].join("\n");
    }
    const d = result as ReportDoc;
    return [d.title, "\nKIRISH", ...d.introduction, ...d.sections.flatMap((s) => [`\n${s.heading.toUpperCase()}`, ...s.paragraphs]), "\nXULOSA", ...d.conclusion, "\nFOYDALANILGAN MANBALAR", ...d.sources.map((s, i) => `${i + 1}. ${s}`)].join("\n\n");
  }

  async function copyAll() {
    await navigator.clipboard.writeText(asPlainText());
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  }

  async function downloadSlides() {
    const d = result as SlideDoc;
    const PptxGenJS = (await import("pptxgenjs")).default;
    const pptx = new PptxGenJS();
    pptx.layout = "LAYOUT_WIDE";
    pptx.author = "Dima'AI";
    pptx.subject = topic;
    pptx.title = d.title;
    pptx.company = "Dima'AI.uz";
    pptx.theme = {
      headFontFace: "Aptos Display",
      bodyFontFace: "Aptos",
    };

    d.slides.forEach((item, index) => {
      const slide = pptx.addSlide();
      slide.background = { color: COLORS.bg };
      slide.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: 0.12, h: 7.5, fill: { color: COLORS.gold }, line: { color: COLORS.gold } });
      slide.addText(`${String(index + 1).padStart(2, "0")}`, { x: 11.3, y: 0.28, w: 1.3, h: 0.4, fontFace: "Aptos", fontSize: 12, bold: true, color: COLORS.gold, align: "right", margin: 0 });
      slide.addText(item.title || `Slayd ${index + 1}`, { x: 0.75, y: 0.6, w: 10.9, h: 0.8, fontFace: "Aptos Display", fontSize: 26, bold: true, color: COLORS.light, margin: 0.02, breakLine: false });
      slide.addShape(pptx.ShapeType.line, { x: 0.75, y: 1.55, w: 1.4, h: 0, line: { color: COLORS.gold, width: 3 } });
      const runs = (item.bullets ?? []).map((b) => ({ text: b, options: { bullet: { indent: 18 }, hanging: 4, breakLine: true, color: COLORS.muted, fontSize: 18, paraSpaceAfterPt: 15 } }));
      slide.addText(runs, { x: 0.9, y: 1.9, w: 10.8, h: 4.6, fontFace: "Aptos", fontSize: 18, color: COLORS.muted, valign: "middle", margin: 0.08, breakLine: false, fit: "shrink" });
      slide.addText("Dima'AI • O'zbek AI platforma", { x: 0.75, y: 7.05, w: 4.5, h: 0.22, fontSize: 8, color: "6F6F7D", margin: 0 });
      if (item.speakerNotes) slide.addNotes(item.speakerNotes);
    });

    const safe = topic.replace(/[^a-zA-Z0-9\u0400-\u04FF'-]+/g, "-").slice(0, 60) || "dima-ai-slayd";
    await pptx.writeFile({ fileName: `${safe}.pptx` });
  }

  async function downloadReport() {
    const d = result as ReportDoc;
    const { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, PageBreak } = await import("docx");
    const children = [
      new Paragraph({ text: d.title, heading: HeadingLevel.TITLE, alignment: AlignmentType.CENTER, spacing: { after: 500 } }),
      new Paragraph({ children: [new TextRun({ text: "Dima'AI yordamida tayyorlandi", italics: true, color: "8A6A16" })], alignment: AlignmentType.CENTER, spacing: { after: 600 } }),
      new Paragraph({ text: "KIRISH", heading: HeadingLevel.HEADING_1 }),
      ...(d.introduction ?? []).map((p) => new Paragraph({ text: p, alignment: AlignmentType.JUSTIFIED, spacing: { after: 220 }, indent: { firstLine: 720 } })),
      ...((d.sections ?? []).flatMap((s) => [
        new Paragraph({ text: s.heading, heading: HeadingLevel.HEADING_1, pageBreakBefore: false }),
        ...(s.paragraphs ?? []).map((p) => new Paragraph({ text: p, alignment: AlignmentType.JUSTIFIED, spacing: { after: 220 }, indent: { firstLine: 720 } })),
      ])),
      new Paragraph({ text: "XULOSA", heading: HeadingLevel.HEADING_1 }),
      ...(d.conclusion ?? []).map((p) => new Paragraph({ text: p, alignment: AlignmentType.JUSTIFIED, spacing: { after: 220 }, indent: { firstLine: 720 } })),
      new Paragraph({ children: [new PageBreak()] }),
      new Paragraph({ text: "FOYDALANILGAN MANBALAR", heading: HeadingLevel.HEADING_1 }),
      ...(d.sources ?? []).map((s, i) => new Paragraph({ text: `${i + 1}. ${s}`, spacing: { after: 120 } })),
    ];
    const doc = new Document({
      creator: "Dima'AI",
      title: d.title,
      description: topic,
      sections: [{ properties: {}, children }],
    });
    const blob = await Packer.toBlob(doc);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${topic.replace(/[^a-zA-Z0-9\u0400-\u04FF'-]+/g, "-").slice(0, 60) || "dima-ai-referat"}.docx`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  }

  async function download() {
    if (!result || downloading) return;
    setDownloading(true);
    setError(null);
    try {
      if (kind === "slides") await downloadSlides();
      else await downloadReport();
    } catch {
      setError("Faylni tayyorlashda xato. Nusxalash tugmasidan foydalaning.");
    }
    setDownloading(false);
  }

  const Icon = kind === "slides" ? Presentation : FileText;

  return (
    <div className="mx-auto w-full max-w-6xl flex-1 overflow-y-auto px-4 pb-24 pt-6 sm:px-6">
      <div className="mb-6 text-center">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-gold-300 to-gold-600 text-ink-950 shadow-[0_8px_30px_rgba(245,192,68,0.35)]"><Icon className="h-7 w-7" /></div>
        <h2 className="font-display text-2xl font-extrabold sm:text-3xl"><span className="text-gold-gradient">AI hujjat studiyasi</span></h2>
        <p className="mt-2 text-sm text-white/50">Pollinations Text bilan bepul. API kalit shart emas.</p>
      </div>

      <div className="mx-auto mb-5 flex max-w-md rounded-2xl border border-white/10 bg-white/[0.03] p-1.5">
        {[{ id: "slides" as Kind, label: "Slayd", icon: Presentation }, { id: "report" as Kind, label: "Referat", icon: FileText }].map((t) => <button key={t.id} onClick={() => switchKind(t.id)} className={`flex flex-1 items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-bold transition ${kind === t.id ? "bg-gradient-to-br from-gold-300 to-gold-600 text-ink-950" : "text-white/55 hover:text-white"}`}><t.icon className="h-4 w-4" />{t.label}</button>)}
      </div>

      <div className="grid gap-5 lg:grid-cols-[360px_1fr]">
        <div className="glass h-fit rounded-2xl p-5 lg:sticky lg:top-4">
          <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-white/45">Mavzu</label>
          <textarea value={topic} onChange={(e) => setTopic(e.target.value)} rows={3} maxLength={300} placeholder={kind === "slides" ? "Masalan: O'zbekistonda ekologik turizm" : "Masalan: Sun'iy intellektning ta'limdagi o'rni"} className="w-full resize-none rounded-xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white placeholder:text-white/30 focus:border-gold-400/50 focus:outline-none" />
          <label className="mb-2 mt-4 block text-xs font-bold uppercase tracking-wider text-white/45">Qo'shimcha talab</label>
          <textarea value={details} onChange={(e) => setDetails(e.target.value)} rows={3} placeholder="Ixtiyoriy: uslub, auditoriya, muhim fikrlar…" className="w-full resize-none rounded-xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white placeholder:text-white/30 focus:border-gold-400/50 focus:outline-none" />
          <label className="mb-2 mt-4 block text-xs font-bold uppercase tracking-wider text-white/45">{kind === "slides" ? "Slaydlar soni" : "Asosiy bo'limlar"}</label>
          <div className="grid grid-cols-4 gap-2">{(kind === "slides" ? [6, 8, 10, 12] : [2, 3, 4, 5]).map((n) => <button key={n} onClick={() => setCount(n)} className={`rounded-xl border px-2 py-2 text-sm font-bold ${count === n ? "border-gold-400/60 bg-gold-400/10 text-gold-300" : "border-white/10 text-white/50"}`}>{n}</button>)}</div>
          <button onClick={generate} disabled={busy || topic.trim().length < 3} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-gold-300 to-gold-600 px-4 py-3.5 font-display text-sm font-bold text-ink-950 shadow-[0_8px_28px_rgba(245,192,68,0.35)] disabled:opacity-40">{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}{busy ? "AI tayyorlamoqda…" : `${kind === "slides" ? "Slayd" : "Referat"} yaratish`}</button>
          {busy && <p className="mt-2 text-center text-[11px] text-white/35">Bepul AI: 10–60 soniya kuting</p>}
          {error && <p className="mt-3 rounded-xl border border-red-400/25 bg-red-500/10 p-3 text-xs text-red-200">{error}</p>}
        </div>

        <div className="min-h-[420px]">
          {!result ? <div className="flex min-h-[420px] flex-col items-center justify-center rounded-2xl border border-dashed border-white/10 px-6 text-center"><Sparkles className="mb-4 h-10 w-10 text-gold-400" /><h3 className="font-display font-bold">Natija shu yerda chiqadi</h3><p className="mt-2 max-w-sm text-sm text-white/40">Mavzuni yozing, AI tayyorlaydi. So'ng haqiqiy {kind === "slides" ? "PowerPoint" : "Word"} faylini yuklab oling.</p></div> : (
            <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }}>
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2"><p className="text-sm font-bold text-gold-300">Tayyor: {kind === "slides" ? `${(result as SlideDoc).slides?.length ?? 0} ta slayd` : "Word referat"}</p><div className="flex gap-2"><button onClick={copyAll} className="flex items-center gap-1.5 rounded-lg border border-white/10 px-3 py-2 text-xs font-bold text-white/65 hover:text-white">{copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}{copied ? "Nusxalandi" : "Nusxalash"}</button><button onClick={download} disabled={downloading} className="flex items-center gap-1.5 rounded-lg bg-gradient-to-br from-gold-300 to-gold-600 px-3 py-2 text-xs font-bold text-ink-950 disabled:opacity-50">{downloading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}{kind === "slides" ? ".PPTX" : ".DOCX"}</button></div></div>
              {kind === "slides" ? <div className="grid gap-3 sm:grid-cols-2">{(result as SlideDoc).slides?.map((s, i) => <div key={i} className="glass aspect-video overflow-hidden rounded-2xl border-l-4 border-l-gold-400 p-4"><div className="flex justify-between gap-3"><h3 className="line-clamp-2 font-display text-sm font-bold">{s.title}</h3><span className="text-[10px] font-bold text-gold-300">{String(i + 1).padStart(2, "0")}</span></div><ul className="mt-3 space-y-1.5">{s.bullets?.slice(0, 5).map((b, j) => <li key={j} className="flex gap-2 text-[11px] leading-relaxed text-white/55"><span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-gold-400" />{b}</li>)}</ul></div>)}</div> : <div className="glass rounded-2xl p-5 sm:p-7"><h1 className="font-display text-xl font-bold text-gold-gradient">{(result as ReportDoc).title}</h1><h2 className="mt-6 font-display text-sm font-bold">KIRISH</h2>{(result as ReportDoc).introduction?.map((p, i) => <p key={i} className="mt-2 text-sm leading-7 text-white/65">{p}</p>)}{(result as ReportDoc).sections?.map((s, i) => <section key={i}><h2 className="mt-6 font-display text-sm font-bold text-gold-200">{s.heading}</h2>{s.paragraphs?.map((p, j) => <p key={j} className="mt-2 text-sm leading-7 text-white/65">{p}</p>)}</section>)}<h2 className="mt-6 font-display text-sm font-bold">XULOSA</h2>{(result as ReportDoc).conclusion?.map((p, i) => <p key={i} className="mt-2 text-sm leading-7 text-white/65">{p}</p>)}</div>}
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
