"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  AlertTriangle,
  Download,
  ExternalLink,
  Image as ImageIcon,
  Loader2,
  RefreshCw,
  Sparkles,
  Wand2,
} from "lucide-react";

type StyleId = "none" | "realistic" | "anime" | "render3d" | "cyberpunk" | "watercolor" | "logo" | "fantasy";
type Ratio = "1:1" | "16:9" | "9:16";
type Quality = "hd" | "2k" | "4k";

const QUALITIES: { id: Quality; label: string; hint: string; tag?: string }[] = [
  { id: "hd", label: "HD", hint: "Tez" },
  { id: "2k", label: "2K", hint: "Aniqroq" },
  { id: "4k", label: "4K ULTRA", hint: "Eng yuqori", tag: "sekinroq" },
];

const STYLES: { id: StyleId; label: string }[] = [
  { id: "none", label: "Erkin" },
  { id: "realistic", label: "Realistik" },
  { id: "anime", label: "Anime" },
  { id: "render3d", label: "3D Render" },
  { id: "cyberpunk", label: "Kiberpank" },
  { id: "watercolor", label: "Akvarel" },
  { id: "fantasy", label: "Fantastika" },
  { id: "logo", label: "Logo" },
];

const RATIOS: { id: Ratio; label: string; hint: string }[] = [
  { id: "1:1", label: "1:1", hint: "Kvadrat" },
  { id: "16:9", label: "16:9", hint: "Gorizontal" },
  { id: "9:16", label: "9:16", hint: "Vertikal" },
];

const IDEAS: { text: string; style: StyleId }[] = [
  { text: "Quyosh botishidagi Registon maydoni, Samarkand", style: "realistic" },
  { text: "Oltin zirh kiygan oq sher, epik sahna", style: "fantasy" },
  { text: "Milliy naqshli zamonaviy logo, oltin rang", style: "logo" },
  { text: "Neon chiroqli kelajak shahri, yomg'ir", style: "cyberpunk" },
];

const STATUS_TEXTS = [
  "AI tasavvur qilmoqda…",
  "Chiziqlar tortilmoqda…",
  "Ranglar aralashtirilmoqda…",
  "Tafsilotlar qo'shilmoqda…",
  "Yakuniy silliqlanmoqda…",
];

type Gen = {
  id: string;
  prompt: string;
  url: string;
  seed: number;
  width: number;
  height: number;
  ratio: Ratio;
  style: StyleId;
  quality: Quality;
  status: "loading" | "done" | "error";
};

let genCounter = 0;

export default function ImageStudio() {
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState<StyleId>("none");
  const [ratio, setRatio] = useState<Ratio>("1:1");
  const [quality, setQuality] = useState<Quality>("hd");
  const [items, setItems] = useState<Gen[]>([]);
  const [apiError, setApiError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Yuklanish xabarlari aylanishi
  useEffect(() => {
    if (!items.some((i) => i.status === "loading")) return;
    const t = setInterval(() => setTick((v) => v + 1), 2400);
    return () => clearInterval(t);
  }, [items]);

  async function generate(customPrompt?: string, customStyle?: StyleId) {
    const p = (customPrompt ?? prompt).trim();
    const s = customStyle ?? style;
    if (p.length < 3) return;
    setApiError(null);
    try {
      const res = await fetch("/api/image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: p, style: s, ratio, quality }),
      });
      const data = await res.json();
      if (!res.ok) {
        setApiError(data.error ?? "Rasm yaratib bo'lmadi");
        return;
      }
      const gen: Gen = {
        id: `g-${Date.now()}-${genCounter++}`,
        prompt: p,
        url: data.url,
        seed: data.seed,
        width: data.width,
        height: data.height,
        ratio,
        style: s,
        quality: data.quality ?? quality,
        status: "loading",
      };
      setItems((prev) => [gen, ...prev]);
    } catch {
      setApiError("Ulanish xatosi. Internetni tekshirib qayta urining.");
    }
  }

  function updateItem(id: string, patch: Partial<Gen>) {
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...patch } : i)));
  }

  async function regenerate(item: Gen) {
    updateItem(item.id, { status: "loading" });
    try {
      const res = await fetch("/api/image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: item.prompt,
          style: item.style,
          ratio: item.ratio,
          quality: item.quality,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        updateItem(item.id, { status: "error" });
        return;
      }
      updateItem(item.id, { url: data.url, seed: data.seed, status: "loading" });
    } catch {
      updateItem(item.id, { status: "error" });
    }
  }

  async function download(item: Gen) {
    try {
      const res = await fetch(item.url);
      const blob = await res.blob();
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `dima-ai-${item.seed}.jpg`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    } catch {
      window.open(item.url, "_blank");
    }
  }

  return (
    <div className="mx-auto w-full max-w-6xl flex-1 overflow-y-auto px-4 pb-24 pt-6 sm:px-6">
      {/* Sarlavha */}
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold sm:text-2xl">
            <span className="text-gold-gradient">Rasm studiyasi</span>
          </h2>
          <p className="mt-1 text-sm text-white/50">
            O'zbek tilida yozing — AI rasm chizadi. To'liq bepul, kalit shart emas.
          </p>
        </div>
        <div className="glass flex items-center gap-2 rounded-full px-4 py-2 text-xs">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
          </span>
          <span className="font-semibold text-emerald-300">Rasm xizmati ishlayapti</span>
          <span className="text-white/40">100% bepul</span>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[380px_1fr]">
        {/* Boshqaruv paneli */}
        <div className="glass h-fit rounded-2xl p-5 lg:sticky lg:top-4">
          <label className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-white/50">
            <Wand2 className="h-3.5 w-3.5 text-gold-400" />
            Rasm tavsifi
          </label>
          <textarea
            ref={inputRef}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={4}
            maxLength={600}
            placeholder="Masalan: registriga oltin quyosh botayotgan Toshkent manzarasi, kinematik uslubda…"
            className="gold-focus w-full resize-none rounded-xl border border-white/10 bg-black/30 px-4 py-3 text-[15px] text-white placeholder:text-white/30 focus:border-gold-400/50 focus:outline-none"
          />
          <div className="mt-1 text-right text-[11px] text-white/30">{prompt.length}/600</div>

          <div className="mt-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-white/50">Uslub</p>
            <div className="flex flex-wrap gap-1.5">
              {STYLES.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setStyle(s.id)}
                  className={`gold-focus rounded-full px-3 py-1.5 text-xs font-medium transition-all ${
                    style === s.id
                      ? "bg-gradient-to-br from-gold-300 to-gold-600 text-ink-950 shadow-[0_2px_14px_rgba(245,192,68,0.35)]"
                      : "border border-white/10 bg-white/[0.04] text-white/60 hover:border-white/25 hover:text-white"
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-white/50">
              O'lcham
            </p>
            <div className="grid grid-cols-3 gap-1.5">
              {RATIOS.map((r) => (
                <button
                  key={r.id}
                  onClick={() => setRatio(r.id)}
                  className={`gold-focus rounded-xl px-2 py-2 text-center transition-all ${
                    ratio === r.id
                      ? "border border-gold-400/60 bg-gold-400/10 text-gold-300"
                      : "border border-white/10 bg-white/[0.04] text-white/60 hover:text-white"
                  }`}
                >
                  <span className="block text-sm font-bold">{r.label}</span>
                  <span className="block text-[10px] opacity-60">{r.hint}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-white/50">
              Sifat
            </p>
            <div className="grid grid-cols-3 gap-1.5">
              {QUALITIES.map((q) => (
                <button
                  key={q.id}
                  onClick={() => setQuality(q.id)}
                  className={`gold-focus relative rounded-xl px-2 py-2 text-center transition-all ${
                    quality === q.id
                      ? "border border-gold-400/60 bg-gold-400/10 text-gold-300"
                      : "border border-white/10 bg-white/[0.04] text-white/60 hover:text-white"
                  }`}
                >
                  <span className="block text-sm font-bold">{q.label}</span>
                  <span className="block text-[10px] opacity-60">{q.hint}</span>
                </button>
              ))}
            </div>
            {quality === "4k" && (
              <p className="mt-2 rounded-lg border border-gold-400/25 bg-gold-400/[0.07] px-3 py-1.5 text-[11px] text-gold-200/80">
                4K ULTRA — eng yuqori sifat, yaratish biroz ko'proq vaqt oladi
              </p>
            )}
          </div>

          <button
            onClick={() => generate()}
            disabled={prompt.trim().length < 3}
            className="gold-focus mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-gold-300 via-gold-400 to-gold-600 px-4 py-3.5 font-display text-sm font-bold text-ink-950 shadow-[0_8px_30px_rgba(245,192,68,0.4)] transition-all hover:brightness-110 active:scale-[0.98] disabled:opacity-40"
          >
            <Sparkles className="h-4 w-4" />
            Rasm yaratish
          </button>

          {apiError && (
            <div className="mt-3 flex items-start gap-2 rounded-xl border border-red-400/30 bg-red-500/10 px-3 py-2.5 text-xs text-red-200">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              {apiError}
            </div>
          )}

          {items.length > 0 && (
            <p className="mt-4 text-center text-[11px] text-white/35">
              Bu sessiyada yaratilgan rasmlar: <span className="text-gold-300">{items.length}</span> ta
            </p>
          )}
        </div>

        {/* Natijalar */}
        <div>
          {items.length === 0 ? (
            <div className="flex h-full min-h-[380px] flex-col items-center justify-center rounded-2xl border border-dashed border-white/10 px-6 py-14 text-center">
              <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-gold-400/10">
                <ImageIcon className="h-8 w-8 text-gold-400" />
              </div>
              <h3 className="font-display text-lg font-bold">Birinchi rasmingizni yarating</h3>
              <p className="mt-1.5 max-w-sm text-sm text-white/45">
                Tavsif yozing yoki quyidagi tayyor g'oyalardan birini tanlang:
              </p>
              <div className="mt-6 grid w-full max-w-md gap-2">
                {IDEAS.map((idea, i) => (
                  <motion.button
                    key={idea.text}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 + i * 0.07 }}
                    onClick={() => {
                      setPrompt(idea.text);
                      setStyle(idea.style);
                      generate(idea.text, idea.style);
                    }}
                    className="glass gold-focus rounded-xl px-4 py-3 text-left text-sm text-white/70 transition-all hover:border-gold-400/40 hover:text-white"
                  >
                    <span className="mr-2 text-gold-400">✦</span>
                    {idea.text}
                  </motion.button>
                ))}
              </div>
            </div>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              <AnimatePresence initial={false}>
                {items.map((item) => (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, scale: 0.92, y: 16 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ type: "spring", bounce: 0.18, duration: 0.55 }}
                    className="glass group overflow-hidden rounded-2xl"
                  >
                    <div
                      className="relative w-full overflow-hidden bg-ink-800"
                      style={{ aspectRatio: `${item.width}/${item.height}` }}
                    >
                      {item.status !== "error" && (
                        <img
                          key={item.url}
                          src={item.url}
                          alt={item.prompt}
                          onLoad={() => updateItem(item.id, { status: "done" })}
                          onError={() => updateItem(item.id, { status: "error" })}
                          className={`absolute inset-0 h-full w-full object-cover transition-all duration-700 ${
                            item.status === "done" ? "opacity-100 blur-0" : "opacity-0 blur-xl"
                          }`}
                        />
                      )}

                      {item.status === "loading" && (
                        <div className="shimmer absolute inset-0 flex flex-col items-center justify-center gap-3">
                          <Loader2 className="h-8 w-8 animate-spin text-gold-400" />
                          <AnimatePresence mode="wait">
                            <motion.p
                              key={tick % STATUS_TEXTS.length}
                              initial={{ opacity: 0, y: 6 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -6 }}
                              className="text-xs text-white/50"
                            >
                              {STATUS_TEXTS[tick % STATUS_TEXTS.length]}
                            </motion.p>
                          </AnimatePresence>
                          <p className="text-[10px] text-white/25">10–40 soniya kuting</p>
                        </div>
                      )}

                      {item.status === "error" && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 px-4 text-center">
                          <AlertTriangle className="h-8 w-8 text-red-300" />
                          <p className="text-sm text-white/60">Rasm yuklanmadi</p>
                          <button
                            onClick={() => regenerate(item)}
                            className="gold-focus inline-flex items-center gap-1.5 rounded-lg border border-gold-400/40 bg-gold-400/10 px-3 py-2 text-xs font-semibold text-gold-300 transition hover:bg-gold-400/20"
                          >
                            <RefreshCw className="h-3.5 w-3.5" /> Qayta urinish
                          </button>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-between gap-2 px-4 py-3">
                      <div className="min-w-0 flex-1">
                        <p className="line-clamp-2 text-xs text-white/55" title={item.prompt}>
                          {item.prompt}
                        </p>
                        <span
                          className={`mt-1.5 inline-block rounded-full px-2 py-0.5 text-[9px] font-extrabold tracking-wider ${
                            item.quality === "4k"
                              ? "bg-gradient-to-r from-gold-300 to-gold-500 text-ink-950"
                              : item.quality === "2k"
                                ? "bg-gold-400/15 text-gold-300"
                                : "bg-white/10 text-white/45"
                          }`}
                        >
                          {item.quality.toUpperCase()}
                        </span>
                      </div>
                      {item.status === "done" && (
                        <div className="flex shrink-0 gap-1">
                          <button
                            onClick={() => download(item)}
                            className="gold-focus rounded-lg border border-white/10 bg-white/[0.05] p-2 text-white/70 transition hover:border-gold-400/50 hover:text-gold-300"
                            title="Yuklab olish"
                          >
                            <Download className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => regenerate(item)}
                            className="gold-focus rounded-lg border border-white/10 bg-white/[0.05] p-2 text-white/70 transition hover:border-gold-400/50 hover:text-gold-300"
                            title="Yangi variant"
                          >
                            <RefreshCw className="h-4 w-4" />
                          </button>
                          <a
                            href={item.url}
                            target="_blank"
                            rel="noreferrer"
                            className="gold-focus rounded-lg border border-white/10 bg-white/[0.05] p-2 text-white/70 transition hover:border-gold-400/50 hover:text-gold-300"
                            title="Yangi oynada ochish"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
