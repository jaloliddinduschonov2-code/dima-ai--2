"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  BadgeCheck,
  Check,
  CreditCard,
  Crown,
  Rocket,
  Send,
  Sparkles,
  X,
  Zap,
} from "lucide-react";
import { TELEGRAM } from "@/lib/public-env";

type PlanId = "start" | "pro" | "turbo";

const PLANS: {
  id: PlanId;
  name: string;
  price: string;
  oldPrice?: string;
  period: string;
  tagline: string;
  icon: typeof Sparkles;
  features: string[];
  highlight?: boolean;
  badge?: string;
}[] = [
  {
    id: "start",
    name: "Dima Start",
    price: "Bepul",
    period: "har doim",
    tagline: "AI bilan tanishish uchun",
    icon: Sparkles,
    features: [
      "3 ta AI chat (AI-1, AI-2, AI-3)",
      "Bepul rasm yaratish",
      "Kunlik bepul limitlar",
      "Ro'yxatdan o'tish — 1 daqiqa",
    ],
  },
  {
    id: "pro",
    name: "Dima Pro",
    price: "50 000 so'm",
    period: "oyiga",
    tagline: "Faol foydalanuvchilar uchun",
    icon: Zap,
    features: [
      "Dima Start'dagi barcha imkoniyatlar",
      "Ko'paytirilgan kunlik limitlar",
      "Ustuvor javob tezligi",
      "Yangi funksiyalarga erta kirish",
    ],
    highlight: true,
    badge: "Ommabop",
  },
  {
    id: "turbo",
    name: "Dima Turbo",
    price: "300 000 so'm",
    oldPrice: "600 000 so'm",
    period: "yiliga",
    tagline: "Eng katta tejash — 1 yilga",
    icon: Crown,
    features: [
      "Dima Pro'dagi barcha imkoniyatlar",
      "Eng yuqori limitlar",
      "Shaxsiy qo'llab-quvvatlash",
      "300 000 so'm tejaladi (50% aksiya)",
    ],
    badge: "-50% aksiya",
  },
];

export default function PricingView({ currentPlan }: { currentPlan?: string }) {
  const [payPlan, setPayPlan] = useState<(typeof PLANS)[number] | null>(null);

  return (
    <div className="mx-auto w-full max-w-6xl flex-1 overflow-y-auto px-4 pb-24 pt-6 sm:px-6">
      <div className="mb-8 text-center">
        <h2 className="font-display text-2xl font-bold sm:text-3xl">
          <span className="text-gold-gradient">Narxlar</span> — oddiy va halol
        </h2>
        <p className="mx-auto mt-2 max-w-xl text-sm text-white/50">
          Dima Start har doim bepul. Premium'ni karta orqali to'lang — chekni Telegram'ga
          yuboring, administrator Premium'ni emailingizga qo'lda yoqadi.
        </p>
      </div>

      <div className="grid gap-5 md:grid-cols-3">
        {PLANS.map((p, i) => {
          const Icon = p.icon;
          const isCurrent = currentPlan === p.id;
          return (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className={`relative flex flex-col rounded-3xl p-6 ${
                p.highlight
                  ? "border border-gold-400/40 bg-gradient-to-b from-gold-400/[0.12] to-white/[0.03] shadow-[0_20px_60px_rgba(245,192,68,0.15)]"
                  : "glass"
              }`}
            >
              {p.badge && (
                <span
                  className={`absolute -top-3 right-5 rounded-full px-3 py-1 text-[11px] font-bold ${
                    p.highlight
                      ? "bg-gradient-to-r from-gold-300 to-gold-500 text-ink-950"
                      : "border border-gold-400/50 bg-ink-900 text-gold-300"
                  }`}
                >
                  {p.badge}
                </span>
              )}

              <div
                className={`mb-4 flex h-12 w-12 items-center justify-center rounded-2xl ${
                  p.highlight
                    ? "bg-gradient-to-br from-gold-300 to-gold-600 text-ink-950"
                    : "bg-gold-400/10 text-gold-400"
                }`}
              >
                <Icon className="h-6 w-6" />
              </div>

              <h3 className="font-display text-lg font-bold">{p.name}</h3>
              <p className="mt-0.5 text-xs text-white/45">{p.tagline}</p>

              <div className="mt-4 flex items-baseline gap-2">
                <span className="font-display text-2xl font-extrabold text-white">
                  {p.price}
                </span>
                <span className="text-xs text-white/40">/ {p.period}</span>
              </div>
              {p.oldPrice && (
                <div className="mt-1 flex items-center gap-2">
                  <span className="text-sm text-white/35 line-through">{p.oldPrice}</span>
                  <span className="rounded-full bg-emerald-400/15 px-2 py-0.5 text-[10px] font-bold text-emerald-300">
                    50% tejaysiz
                  </span>
                </div>
              )}

              <ul className="mt-5 flex-1 space-y-2.5">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-sm text-white/70">
                    <Check
                      className={`mt-0.5 h-4 w-4 shrink-0 ${
                        p.highlight ? "text-gold-300" : "text-gold-400/80"
                      }`}
                    />
                    {f}
                  </li>
                ))}
              </ul>

              <button
                onClick={() => {
                  if (p.id !== "start") setPayPlan(p);
                }}
                disabled={isCurrent || p.id === "start"}
                className={`gold-focus mt-6 flex w-full items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-bold transition-all active:scale-[0.98] ${
                  isCurrent
                    ? "border border-emerald-400/40 bg-emerald-400/10 text-emerald-300"
                    : p.id === "start"
                      ? "border border-white/10 bg-white/[0.04] text-white/50"
                      : p.highlight
                        ? "bg-gradient-to-br from-gold-300 to-gold-600 text-ink-950 shadow-[0_8px_30px_rgba(245,192,68,0.35)] hover:brightness-110"
                        : "border border-gold-400/40 bg-gold-400/10 text-gold-300 hover:bg-gold-400/20"
                }`}
              >
                {isCurrent ? (
                  <>
                    <BadgeCheck className="h-4 w-4" /> Hozirgi rejangiz
                  </>
                ) : p.id === "start" ? (
                  "Bepul reja"
                ) : (
                  <>
                    <CreditCard className="h-4 w-4" /> Premium'ga o'tish
                  </>
                )}
              </button>
            </motion.div>
          );
        })}
      </div>

      <p className="mt-8 text-center text-xs text-white/35">
        To'lov karta orqali qabul qilinadi. Chek yuborilgach, Premium 24 soat ichida
        emailingizga qo'lda faollashtiriladi.
      </p>

      {/* To'lov yo'riqnomasi modali */}
      <AnimatePresence>
        {payPlan && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[70] flex items-end justify-center bg-black/70 p-4 backdrop-blur-sm sm:items-center"
            onClick={() => setPayPlan(null)}
          >
            <motion.div
              initial={{ opacity: 0, y: 40, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 40, scale: 0.96 }}
              transition={{ type: "spring", bounce: 0.2 }}
              onClick={(e) => e.stopPropagation()}
              className="glass w-full max-w-md rounded-3xl bg-ink-900/90 p-6 shadow-2xl"
            >
              <div className="mb-4 flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-gold-300 to-gold-600 text-ink-950">
                    <payPlan.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold">{payPlan.name}</h3>
                    <p className="text-xs text-gold-300">
                      {payPlan.price} / {payPlan.period}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setPayPlan(null)}
                  className="gold-focus rounded-lg p-1.5 text-white/50 transition hover:bg-white/10 hover:text-white"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="space-y-3">
                {[
                  {
                    icon: CreditCard,
                    title: "1. Karta orqali to'lang",
                    desc: `${payPlan.price} miqdorini administrator ko'rsatgan karta raqamiga o'tkazing.`,
                  },
                  {
                    icon: Send,
                    title: "2. Chekni Telegram'ga yuboring",
                    desc: "To'lov chekini skrinshot qilib, Telegram orqali adminga yuboring. Emailingizni yozishni unutmang.",
                  },
                  {
                    icon: BadgeCheck,
                    title: "3. Premium yoqiladi",
                    desc: "Administrator tekshirib, Premium'ni emailingizga qo'lda yoqadi (odatda 24 soat ichida).",
                  },
                ].map((s) => (
                  <div key={s.title} className="flex gap-3 rounded-xl border border-white/8 bg-white/[0.03] p-3.5">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gold-400/10 text-gold-400">
                      <s.icon className="h-4.5 w-4.5" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold">{s.title}</p>
                      <p className="mt-0.5 text-xs leading-relaxed text-white/50">{s.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-5 grid gap-2">
                <a
                  href={TELEGRAM.admin}
                  target="_blank"
                  rel="noreferrer"
                  className="gold-focus flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-gold-300 to-gold-600 px-4 py-3 font-display text-sm font-bold text-ink-950 shadow-[0_8px_30px_rgba(245,192,68,0.35)] transition hover:brightness-110"
                >
                  <Send className="h-4 w-4" /> Admin bilan bog'lanish (@Dima_ai_admin)
                </a>
                <a
                  href={TELEGRAM.channel}
                  target="_blank"
                  rel="noreferrer"
                  className="gold-focus flex w-full items-center justify-center gap-2 rounded-xl border border-sky-400/30 bg-sky-400/10 px-4 py-2.5 text-sm font-bold text-sky-200 transition hover:bg-sky-400/20"
                >
                  <Send className="h-4 w-4" /> Telegram kanalga qo'shilish
                </a>
              </div>

              <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-[11px] text-white/30">
                <Rocket className="h-3 w-3" />
                To'lov cheki va emailingizni adminga yuboring — Premium 24 soat ichida yoqiladi
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
