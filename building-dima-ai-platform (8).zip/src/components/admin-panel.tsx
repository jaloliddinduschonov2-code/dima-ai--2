"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  BadgeCheck,
  Banknote,
  ChevronDown,
  Copy,
  Crown,
  Image as ImageIcon,
  KeyRound,
  Link2,
  MessageSquare,
  RefreshCw,
  Search,
  ShieldCheck,
  Users,
  X,
} from "lucide-react";
import type { AdminStats, AdminUser } from "@/lib/admin";

type StatsRes = AdminStats;
type UserRes = AdminUser;

const PLANS: { id: string; label: string; icon?: typeof Crown }[] = [
  { id: "start", label: "Start" },
  { id: "pro", label: "Pro" },
  { id: "turbo", label: "Turbo" },
];

function Badge({ plan, role }: { plan: string; role: string }) {
  if (role === "admin") {
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-400/15 px-2 py-0.5 text-[10px] font-bold text-emerald-300">
        <ShieldCheck className="h-3 w-3" /> ADMIN
      </span>
    );
  }
  if (plan === "start") {
    return (
      <span className="inline-flex rounded-full bg-white/10 px-2 py-0.5 text-[10px] font-bold text-white/55">
        Start
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-gold-400/15 px-2 py-0.5 text-[10px] font-bold text-gold-300">
      <Crown className="h-3 w-3" /> {plan === "pro" ? "Pro" : "Turbo"}
    </span>
  );
}

function UserMoneyActions({
  user,
  busy,
  onBalance,
  onReset,
}: {
  user: UserRes;
  busy: boolean;
  onBalance: (id: string, delta: number) => void;
  onReset: (id: string) => void;
}) {
  const [amount, setAmount] = useState("50000");
  const value = Math.max(0, Math.round(Number(amount.replace(/\D/g, "")) || 0));
  return (
    <div className="min-w-[210px] space-y-2">
      <div className="flex items-center justify-between rounded-lg bg-gold-400/[0.08] px-2.5 py-1.5 text-xs">
        <span className="flex items-center gap-1.5 text-white/45"><Banknote className="h-3.5 w-3.5" /> Balans</span>
        <span className="font-bold text-gold-300">{user.balanceSoms.toLocaleString("uz-UZ")} so'm</span>
      </div>
      <div className="flex gap-1.5">
        <input
          inputMode="numeric"
          value={amount}
          onChange={(e) => setAmount(e.target.value.replace(/\D/g, "").slice(0, 9))}
          className="min-w-0 flex-1 rounded-lg border border-white/10 bg-black/30 px-2 py-1.5 text-xs text-white focus:border-gold-400/50 focus:outline-none"
          placeholder="Summa"
        />
        <button disabled={busy || !value} onClick={() => onBalance(user.id, value)} className="rounded-lg bg-emerald-400/15 px-2.5 py-1.5 text-xs font-bold text-emerald-300 disabled:opacity-40">+</button>
        <button disabled={busy || !value} onClick={() => onBalance(user.id, -value)} className="rounded-lg bg-red-400/10 px-2.5 py-1.5 text-xs font-bold text-red-300 disabled:opacity-40">−</button>
      </div>
      <button onClick={() => onReset(user.id)} disabled={busy} className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-white/10 px-2 py-1.5 text-[11px] font-semibold text-white/55 transition hover:border-gold-400/30 hover:text-gold-300 disabled:opacity-40"><Link2 className="h-3 w-3" /> Reset havolasini nusxalash</button>
    </div>
  );
}

function PlanPicker({
  current,
  onPick,
  disabled,
}: {
  current: string;
  onPick: (plan: string) => void;
  disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button
        disabled={disabled}
        onClick={() => setOpen((v) => !v)}
        className="gold-focus flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.04] px-2.5 py-1.5 text-xs font-semibold text-white/80 transition hover:border-gold-400/40 disabled:opacity-50"
      >
        Reja: {current}
        <ChevronDown className={`h-3 w-3 transition ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 z-20 mt-1 w-32 overflow-hidden rounded-xl border border-white/10 bg-ink-850 py-1 shadow-2xl">
            {PLANS.map((p) => (
              <button
                key={p.id}
                onClick={() => {
                  onPick(p.id);
                  setOpen(false);
                }}
                className={`flex w-full items-center justify-between px-3 py-2 text-left text-xs font-semibold transition hover:bg-gold-400/10 ${
                  current === p.id ? "text-gold-300" : "text-white/70"
                }`}
              >
                {p.label}
                {current === p.id && <BadgeCheck className="h-3.5 w-3.5" />}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default function AdminPanel() {
  const [stats, setStats] = useState<StatsRes | null>(null);
  const [users, setUsers] = useState<UserRes[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [bussyId, setBussyId] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setErr(null);
    try {
      const [sRes, uRes] = await Promise.all([
        fetch("/api/admin/stats").then((r) => r.json()),
        fetch("/api/admin/users").then((r) => r.json()),
      ]);
      if (uRes.error || sRes.error) {
        setErr(uRes.error || sRes.error || "Kirish rad etildi");
      } else {
        setStats(sRes);
        setUsers(uRes.users);
      }
    } catch {
      setErr("Server bilan bog'lanib bo'lmadi");
    }
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function changePlan(userId: string, plan: string) {
    setBussyId(userId);
    try {
      const r = await fetch("/api/admin/users", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: userId, plan }),
      });
      const d = await r.json();
      if (!r.ok) setToast(d.error ?? "Xato");
      else {
        setUsers((prev) => prev.map((u) => (u.id === userId ? { ...u, plan } : u)));
        setToast("Reja yangilandi");
        load();
      }
    } finally {
      setBussyId(null);
      setTimeout(() => setToast(null), 2500);
    }
  }

  async function changeBalance(userId: string, balanceDelta: number) {
    setBussyId(userId);
    try {
      const r = await fetch("/api/admin/users", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: userId, balanceDelta, note: "Admin panel orqali" }),
      });
      const d = await r.json();
      if (!r.ok) setToast(d.error ?? "Balans o'zgarmadi");
      else {
        setUsers((prev) =>
          prev.map((u) =>
            u.id === userId ? { ...u, balanceSoms: d.user.balanceSoms } : u,
          ),
        );
        setToast(`${Math.abs(balanceDelta).toLocaleString("uz-UZ")} so'm ${balanceDelta > 0 ? "qo'shildi" : "ayirildi"}`);
      }
    } finally {
      setBussyId(null);
      setTimeout(() => setToast(null), 2800);
    }
  }

  async function copyResetLink(userId: string) {
    setBussyId(userId);
    try {
      const r = await fetch("/api/admin/reset-link", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: userId }),
      });
      const d = await r.json();
      if (!r.ok) setToast(d.error ?? "Havola yaratilmadi");
      else {
        await navigator.clipboard.writeText(d.resetUrl);
        setToast("Reset havolasi nusxalandi — foydalanuvchiga yuboring");
      }
    } catch {
      setToast("Havolani nusxalab bo'lmadi");
    } finally {
      setBussyId(null);
      setTimeout(() => setToast(null), 3500);
    }
  }

  const filtered = users.filter((u) => {
    const q = query.trim().toLowerCase();
    if (!q) return true;
    return (
      u.email.toLowerCase().includes(q) ||
      (u.name ?? "").toLowerCase().includes(q)
    );
  });

  const statCards = [
    {
      label: "Jami foydalanuvchilar",
      value: stats?.totalUsers ?? 0,
      icon: Users,
      color: "from-gold-300 to-gold-600",
    },
    {
      label: "Premium egalari",
      value: stats?.premiumUsers ?? 0,
      icon: Crown,
      color: "from-purple-400 to-fuchsia-600",
    },
    {
      label: "Rasm (bugun)",
      value: stats?.imagesToday ?? 0,
      icon: ImageIcon,
      color: "from-sky-400 to-cyan-600",
    },
    {
      label: "Xabarlar (bugun)",
      value: stats?.messagesToday ?? 0,
      icon: MessageSquare,
      color: "from-emerald-400 to-emerald-600",
    },
  ];

  return (
    <div className="mx-auto w-full max-w-6xl flex-1 overflow-y-auto px-4 pb-24 pt-6 sm:px-6">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="mb-2 inline-flex items-center gap-2 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-3 py-1 text-xs font-bold text-emerald-300">
            <ShieldCheck className="h-3.5 w-3.5" /> Admin panel
          </div>
          <h2 className="font-display text-2xl font-extrabold sm:text-3xl">
            <span className="text-gold-gradient">Boshqaruv paneli</span>
          </h2>
          <p className="mt-1 text-sm text-white/50">
            Foydalanuvchilarni ko'ring, Premium rejalarni qo'lda yoqing.
          </p>
        </div>
        <button
          onClick={load}
          disabled={loading}
          className="gold-focus inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-4 py-2 text-xs font-bold text-white/80 transition hover:border-gold-400/40 disabled:opacity-50"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} /> Yangilash
        </button>
      </div>

      {/* Stat kartalar */}
      <div className="mb-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {statCards.map((c) => (
          <motion.div
            key={c.label}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass rounded-2xl p-4"
          >
            <div
              className={`mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${c.color} text-ink-950`}
            >
              <c.icon className="h-5 w-5" />
            </div>
            <p className="font-display text-2xl font-extrabold">
              {loading ? "…" : (c.value ?? 0).toLocaleString("uz-UZ")}
            </p>
            <p className="mt-0.5 text-xs text-white/45">{c.label}</p>
          </motion.div>
        ))}
      </div>

      {/* Qidiruv */}
      <div className="glass mb-4 flex items-center gap-2.5 rounded-2xl px-4 py-3">
        <Search className="h-4 w-4 shrink-0 text-white/40" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Email yoki ism bo'yicha qidirish…"
          className="w-full bg-transparent text-sm text-white placeholder:text-white/30 focus:outline-none"
        />
        {query && (
          <button onClick={() => setQuery("")} className="text-white/40 transition hover:text-white">
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {err ? (
        <div className="rounded-2xl border border-red-400/30 bg-red-500/10 p-6 text-center">
          <KeyRound className="mx-auto mb-2 h-8 w-8 text-red-300" />
          <p className="text-sm font-semibold text-red-200">Kirish rad etildi</p>
          <p className="mt-1 text-xs text-red-200/70">{err}</p>
        </div>
      ) : (
        <div className="glass overflow-hidden rounded-2xl">
          {/* Jadval (desktop) */}
          <div className="hidden md:block">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/[0.07] text-left text-[10px] font-bold uppercase tracking-wider text-white/40">
                  <th className="px-5 py-3">Foydalanuvchi</th>
                  <th className="px-5 py-3">Reja</th>
                  <th className="px-5 py-3">Faollik</th>
                  <th className="px-5 py-3">Qo'shilgan</th>
                  <th className="px-5 py-3 text-right">Amal</th>
                </tr>
              </thead>
              <tbody>
                {loading && users.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-5 py-14 text-center text-sm text-white/40">
                      Yuklanmoqda…
                    </td>
                  </tr>
                ) : filtered.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-5 py-14 text-center text-sm text-white/40">
                      Hech narsa topilmadi
                    </td>
                  </tr>
                ) : (
                  filtered.map((u) => (
                    <tr
                      key={u.id}
                      className="border-b border-white/[0.05] text-sm transition last:border-0 hover:bg-white/[0.02]"
                    >
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-3">
                          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-gold-300 to-gold-600 font-display text-sm font-extrabold text-ink-950">
                            {(u.name || u.email)[0].toUpperCase()}
                          </span>
                          <div className="min-w-0">
                            <p className="truncate font-semibold">
                              {u.name || u.email.split("@")[0]}
                            </p>
                            <p className="truncate text-xs text-white/45">{u.email}</p>
                          </div>
                          <Badge plan={u.plan} role={u.role} />
                        </div>
                      </td>
                      <td className="px-5 py-3">
                        <PlanPicker
                          current={u.plan}
                          onPick={(p) => changePlan(u.id, p)}
                          disabled={bussyId === u.id}
                        />
                      </td>
                      <td className="px-5 py-3 text-xs text-white/60">
                        <div>{u.messagesTotal} xabar</div>
                        <div className="text-white/40">{u.imagesTotal} rasm</div>
                      </td>
                      <td className="px-5 py-3 text-xs text-white/45">
                        {new Date(u.createdAt).toLocaleDateString("uz-UZ")}
                      </td>
                      <td className="px-5 py-3">
                        <UserMoneyActions
                          user={u}
                          busy={bussyId === u.id}
                          onBalance={changeBalance}
                          onReset={copyResetLink}
                        />
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Kartalar (telefon) */}
          <div className="divide-y divide-white/[0.05] md:hidden">
            {loading && users.length === 0 ? (
              <p className="px-5 py-14 text-center text-sm text-white/40">Yuklanmoqda…</p>
            ) : filtered.length === 0 ? (
              <p className="px-5 py-14 text-center text-sm text-white/40">Hech narsa topilmadi</p>
            ) : (
              filtered.map((u) => (
                <div key={u.id} className="px-4 py-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex min-w-0 items-center gap-3">
                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-gold-300 to-gold-600 font-display text-sm font-extrabold text-ink-950">
                        {(u.name || u.email)[0].toUpperCase()}
                      </span>
                      <div className="min-w-0">
                        <p className="truncate font-semibold">{u.name || u.email.split("@")[0]}</p>
                        <p className="truncate text-xs text-white/45">{u.email}</p>
                        <div className="mt-1.5 flex flex-wrap gap-1.5">
                          <Badge plan={u.plan} role={u.role} />
                        </div>
                      </div>
                    </div>
                    <PlanPicker
                      current={u.plan}
                      onPick={(p) => changePlan(u.id, p)}
                      disabled={bussyId === u.id || u.role === "admin"}
                    />
                  </div>
                  <div className="mt-3 flex items-center justify-between text-[11px] text-white/45">
                    <span>{new Date(u.createdAt).toLocaleDateString("uz-UZ")}</span>
                    <span>
                      {u.messagesTotal} xabar · {u.imagesTotal} rasm
                    </span>
                  </div>
                  <div className="mt-3 border-t border-white/[0.06] pt-3">
                    <UserMoneyActions
                      user={u}
                      busy={bussyId === u.id}
                      onBalance={changeBalance}
                      onReset={copyResetLink}
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      <p className="mt-5 text-center text-[11px] text-white/35">
        Admin panel faqat belgilangan email egalariga ko'rinadi. O'zgarishlar real vaqtda bazaga
        yoziladi.
      </p>

      {/* Toast */}
      {toast && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed bottom-24 left-1/2 z-50 -translate-x-1/2 rounded-xl border border-gold-400/40 bg-ink-900/95 px-5 py-3 text-sm font-semibold text-gold-200 shadow-2xl backdrop-blur md:bottom-8"
        >
          {toast}
        </motion.div>
      )}
    </div>
  );
}
