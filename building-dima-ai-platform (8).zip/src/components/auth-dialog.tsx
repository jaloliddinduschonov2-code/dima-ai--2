"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  KeyRound,
  Loader2,
  Lock,
  Mail,
  User as UserIcon,
  X,
} from "lucide-react";
import type { PublicUser } from "@/lib/types";

function GoogleG({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" aria-hidden>
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
    </svg>
  );
}

export default function AuthDialog({
  open,
  onClose,
  onAuth,
}: {
  open: boolean;
  onClose: () => void;
  onAuth: (user: PublicUser) => void;
}) {
  const [mode, setMode] = useState<"login" | "register" | "forgot">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [googleBusy, setGoogleBusy] = useState(false);
  const [googleReady, setGoogleReady] = useState<boolean | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    fetch("/api/auth/google/status")
      .then((r) => r.json())
      .then((d) => setGoogleReady(Boolean(d.configured)))
      .catch(() => setGoogleReady(false));
  }, [open]);

  function startGoogle() {
    if (!googleReady) {
      setError("Google orqali kirish hozircha ulanmagan. Email/parol bilan kiring.");
      return;
    }
    setGoogleBusy(true);
    setError(null);
    window.location.href = "/api/auth/google?redirect=/app";
  }

  async function forgotPassword() {
    setError(null);
    setNotice(null);
    if (!email.trim()) return setError("Email manzilingizni kiriting");
    setBusy(true);
    try {
      const res = await fetch("/api/auth/forgot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim() }),
      });
      const data = await res.json();
      if (!res.ok) setError(data.error ?? "So'rov bajarilmadi");
      else setNotice(data.message);
    } catch {
      setError("Internet xatosi. Qayta urinib ko'ring.");
    }
    setBusy(false);
  }

  async function submit() {
    if (busy) return;
    setError(null);
    if (!email.trim() || !password) return setError("Email va parolni kiriting");
    setBusy(true);
    try {
      const res = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim(), password, name: name.trim() || undefined }),
      });
      const data = await res.json();
      if (!res.ok) setError(data.error ?? "Xatolik yuz berdi");
      else {
        onAuth(data.user);
        onClose();
        setEmail("");
        setPassword("");
        setName("");
      }
    } catch {
      setError("Ulanish xatosi. Qayta urinib ko'ring.");
    }
    setBusy(false);
  }

  const title = mode === "login" ? "Kirish" : mode === "register" ? "Ro'yxatdan o'tish" : "Parolni tiklash";

  return (
    <AnimatePresence>
      {open && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[70] flex items-end justify-center bg-black/70 p-4 backdrop-blur-sm sm:items-center" onClick={onClose}>
          <motion.div initial={{ opacity: 0, y: 40, scale: 0.96 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 40, scale: 0.96 }} transition={{ type: "spring", bounce: 0.2 }} onClick={(e) => e.stopPropagation()} className="glass w-full max-w-sm rounded-3xl bg-ink-900/95 p-6 shadow-2xl">
            <div className="mb-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                {mode === "forgot" && <button onClick={() => { setMode("login"); setError(null); setNotice(null); }} className="rounded-lg p-1.5 text-white/50 hover:bg-white/10 hover:text-white"><ArrowLeft className="h-4 w-4" /></button>}
                <h3 className="font-display text-lg font-bold text-gold-gradient">{title}</h3>
              </div>
              <button onClick={onClose} className="rounded-lg p-1.5 text-white/50 hover:bg-white/10 hover:text-white"><X className="h-5 w-5" /></button>
            </div>

            {mode === "forgot" ? (
              <>
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-gold-400/10 text-gold-300"><KeyRound className="h-6 w-6" /></div>
                <p className="mb-4 text-sm leading-relaxed text-white/50">Emailingizni kiriting. Tiklash havolasi 30 daqiqa ishlaydi. Google bilan ro'yxatdan o'tgan bo'lsangiz, Google tugmasidan ham kirishingiz mumkin.</p>
                <div className="flex items-center gap-2.5 rounded-xl border border-white/10 bg-black/30 px-3.5 py-3 focus-within:border-gold-400/50">
                  <Mail className="h-4 w-4 text-white/35" />
                  <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} onKeyDown={(e) => e.key === "Enter" && forgotPassword()} placeholder="Email manzilingiz" className="w-full bg-transparent text-sm text-white placeholder:text-white/30 focus:outline-none" />
                </div>
                {notice && <div className="mt-3 flex gap-2 rounded-xl border border-emerald-400/25 bg-emerald-400/10 p-3 text-xs leading-relaxed text-emerald-200"><CheckCircle2 className="h-4 w-4 shrink-0" />{notice}</div>}
                {error && <p className="mt-3 rounded-lg border border-red-400/30 bg-red-500/10 px-3 py-2 text-xs text-red-200">{error}</p>}
                <button onClick={forgotPassword} disabled={busy} className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-gold-300 to-gold-600 px-4 py-3 font-display text-sm font-bold text-ink-950 disabled:opacity-50">{busy && <Loader2 className="h-4 w-4 animate-spin" />} Tiklash so'rovini yuborish</button>
                <button onClick={startGoogle} disabled={!googleReady || googleBusy} className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl border border-white/15 bg-white px-4 py-2.5 text-sm font-bold text-ink-950 disabled:opacity-50"><GoogleG /> Google orqali xavfsiz kirish</button>
              </>
            ) : (
              <>
                <button onClick={startGoogle} disabled={googleBusy || googleReady === null} className="relative flex w-full items-center justify-center gap-3 rounded-xl border border-white/15 bg-white px-4 py-2.5 text-sm font-bold text-ink-950 transition hover:bg-white/95 disabled:opacity-50">
                  {googleBusy || googleReady === null ? <Loader2 className="h-5 w-5 animate-spin" /> : <GoogleG />}
                  {mode === "login" ? "Google bilan kirish" : "Google bilan ro'yxatdan o'tish"}
                  {googleReady === false && <span className="absolute -top-2 right-3 inline-flex items-center gap-1 rounded-full bg-amber-400 px-2 py-0.5 text-[9px] font-extrabold"><AlertTriangle className="h-2.5 w-2.5" /> SOZLANMOQDA</span>}
                </button>
                <div className="my-4 flex items-center gap-3 text-[10px] font-bold uppercase tracking-widest text-white/25"><span className="h-px flex-1 bg-white/10" /> yoki email bilan <span className="h-px flex-1 bg-white/10" /></div>
                <div className="mb-3 flex rounded-xl border border-white/10 bg-black/30 p-1">
                  {([{ id: "login", label: "Kirish" }, { id: "register", label: "Ro'yxatdan o'tish" }] as const).map((t) => (
                    <button key={t.id} onClick={() => { setMode(t.id); setError(null); }} className={`flex-1 rounded-lg px-3 py-2 text-xs font-bold ${mode === t.id ? "bg-gradient-to-br from-gold-300 to-gold-500 text-ink-950" : "text-white/55"}`}>{t.label}</button>
                  ))}
                </div>
                <div className="space-y-3">
                  {mode === "register" && <div className="flex items-center gap-2.5 rounded-xl border border-white/10 bg-black/30 px-3.5 py-3"><UserIcon className="h-4 w-4 text-white/35" /><input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ismingiz" className="w-full bg-transparent text-sm focus:outline-none" /></div>}
                  <div className="flex items-center gap-2.5 rounded-xl border border-white/10 bg-black/30 px-3.5 py-3"><Mail className="h-4 w-4 text-white/35" /><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email manzilingiz" className="w-full bg-transparent text-sm focus:outline-none" /></div>
                  <div className="flex items-center gap-2.5 rounded-xl border border-white/10 bg-black/30 px-3.5 py-3"><Lock className="h-4 w-4 text-white/35" /><input type="password" value={password} onChange={(e) => setPassword(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} placeholder={mode === "register" ? "Parol (kamida 6 belgi)" : "Parol"} className="w-full bg-transparent text-sm focus:outline-none" /></div>
                </div>
                {mode === "login" && <button onClick={() => { setMode("forgot"); setError(null); }} className="mt-2 text-xs font-semibold text-gold-300 hover:text-gold-200">Parolni unutdingizmi?</button>}
                {error && <p className="mt-3 rounded-lg border border-red-400/30 bg-red-500/10 px-3 py-2 text-xs text-red-200">{error}</p>}
                <button onClick={submit} disabled={busy} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-gold-300 to-gold-600 px-4 py-3 font-display text-sm font-bold text-ink-950 disabled:opacity-50">{busy && <Loader2 className="h-4 w-4 animate-spin" />}{mode === "login" ? "Kirish" : "Hisob yaratish"}</button>
              </>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
