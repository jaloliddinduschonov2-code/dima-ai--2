"use client";

import Link from "next/link";
import dynamic from "next/dynamic";
import { motion } from "framer-motion";
import {
  ArrowRight,
  BadgePercent,
  CreditCard,
  Crown,
  Image as ImageIcon,
  Languages,
  MessageSquare,
  MonitorSmartphone,
  MousePointerClick,
  Send,
  ShieldCheck,
  Sparkles,
  Wand2,
  Zap,
} from "lucide-react";
import { TELEGRAM } from "@/lib/public-env";

// 3D sahna faqat brauzerda yuklanadi (SSR keraksiz)
const Hero3D = dynamic(() => import("@/components/hero-3d"), { ssr: false });

const MARQUEE_ITEMS = [
  "DIMA TURBO — YILIGA 300 000 SO'M",
  "-50% AKSİYA",
  "4K RASM YARATISH",
  "3 TA AI CHAT",
  "100% O'ZBEK TILIDA",
  "BEPUL BOSHLASH",
  "GROQ TEZLIGI",
];

const FEATURES = [
  {
    icon: MessageSquare,
    title: "3 ta AI chat",
    desc: "AI-1 va AI-2 — kuchli 120B model, AI-3 — tezkor 20B. Savolingizga mos rejimni tanlang.",
  },
  {
    icon: ImageIcon,
    title: "4K rasm yaratish",
    desc: "O'zbekcha yozsangiz ham bo'ladi — AI tavsifingizni 4K sifatli tasvirga aylantiradi.",
  },
  {
    icon: Zap,
    title: "Groq tezligi",
    desc: "Javoblar bir zumda — so'zma-so'z, kutishsiz. Dunyodagi eng tez AI infratuzilma.",
  },
  {
    icon: Languages,
    title: "To'liq o'zbekcha",
    desc: "Interfeys ham, AI javoblari ham ona tilingizda. Tarjimon shart emas.",
  },
  {
    icon: Crown,
    title: "Premium rejalar",
    desc: "Dima Pro va Dima Turbo — kattaroq limitlar, ustuvor tezlik, shaxsiy yordam.",
  },
  {
    icon: ShieldCheck,
    title: "Xavfsiz hisob",
    desc: "Email bilan himoyalangan kirish. Ma'lumotlaringiz faqat sizniki.",
  },
];

const STEPS = [
  {
    n: "01",
    icon: MousePointerClick,
    title: "Saytga kiring",
    desc: "Ro'yxatdan o'tish 1 daqiqa — faqat email va parol. Bank kartasi shart emas.",
  },
  {
    n: "02",
    icon: MessageSquare,
    title: "AI bilan suhbatlashing",
    desc: "3 ta chat rejimidan birini tanlang va savolingizni o'zbekcha yozing.",
  },
  {
    n: "03",
    icon: Wand2,
    title: "Rasm yarating",
    desc: "Xayolingizdagini yozing — 4K sifatda rasm tayyor. Yuklab oling, ulashing.",
  },
];

const fadeUp = {
  initial: { opacity: 0, y: 26 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-80px" },
};

export default function LandingPage() {
  return (
    <div className="relative overflow-x-clip bg-ink-950">
      {/* ===== Yuqori panel ===== */}
      <header className="fixed inset-x-0 top-0 z-50 border-b border-white/[0.06] bg-ink-950/60 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <Link href="/" className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-gold-300 via-gold-400 to-gold-600 font-display text-lg font-extrabold text-ink-950 shadow-[0_4px_20px_rgba(245,192,68,0.4)]">
              D
            </span>
            <span className="font-display text-[15px] font-bold">
              Dima<span className="text-gold-gradient">'AI</span>
            </span>
          </Link>
          <nav className="hidden items-center gap-7 text-sm font-medium text-white/60 md:flex">
            <a href="#imkoniyatlar" className="transition hover:text-gold-300">Imkoniyatlar</a>
            <a href="#qanday" className="transition hover:text-gold-300">Qanday ishlaydi</a>
            <a href="#narxlar" className="transition hover:text-gold-300">Narxlar</a>
          </nav>
          <Link
            href="/app"
            className="gold-focus flex items-center gap-2 rounded-xl bg-gradient-to-br from-gold-300 to-gold-600 px-4 py-2.5 text-sm font-bold text-ink-950 shadow-[0_4px_20px_rgba(245,192,68,0.35)] transition hover:brightness-110 active:scale-95"
          >
            Ilovaga kirish
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </header>

      {/* ===== HERO — 3D orqa fon bilan ===== */}
      <section className="relative flex min-h-[100svh] flex-col items-center justify-center overflow-hidden px-4 pb-16 pt-24 text-center">
        <Hero3D />

        <div className="relative z-10 mx-auto max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full border border-gold-400/30 bg-gold-400/[0.08] px-4 py-1.5 text-xs font-bold text-gold-300"
          >
            <Sparkles className="h-3.5 w-3.5" />
            100% bepul • O'zbek tilida • Kalit shart emas
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.08 }}
            className="font-display text-[34px] font-extrabold leading-[1.08] sm:text-6xl lg:text-7xl"
          >
            O'zbek tilidagi
            <br />
            <span className="text-gold-gradient">BEPUL AI</span> platforma
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.16 }}
            className="mx-auto mt-5 max-w-xl text-balance text-sm leading-relaxed text-white/55 sm:text-base"
          >
            3 ta AI chat, <span className="font-semibold text-gold-300">4K rasm yaratish</span> va
            Premium imkoniyatlar — barchasi bitta joyda. Telefoningizdan kirasiz va darhol
            boshlaysiz.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.24 }}
            className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row"
          >
            <Link
              href="/app"
              className="gold-focus group flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-br from-gold-300 via-gold-400 to-gold-600 px-8 py-4 font-display text-sm font-bold text-ink-950 shadow-[0_12px_44px_rgba(245,192,68,0.45)] transition hover:brightness-110 active:scale-[0.98] sm:w-auto"
            >
              Bepul boshlash
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              href="/app?view=image"
              className="glass gold-focus flex w-full items-center justify-center gap-2 rounded-2xl px-8 py-4 font-display text-sm font-bold text-white transition hover:border-gold-400/40 hover:text-gold-200 sm:w-auto"
            >
              <ImageIcon className="h-4 w-4 text-gold-400" />
              4K rasm yaratish
            </Link>
          </motion.div>

          {/* Statistika */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.36 }}
            className="mx-auto mt-14 grid max-w-2xl grid-cols-2 gap-3 sm:grid-cols-4"
          >
            {[
              ["3 ta", "AI chat rejimi"],
              ["4K", "rasm sifati"],
              ["0 so'm", "boshlash uchun"],
              ["1 daqiqa", "ro'yxatdan o'tish"],
            ].map(([big, small]) => (
              <div key={small} className="glass rounded-2xl px-3 py-4">
                <p className="font-display text-xl font-extrabold text-gold-gradient">{big}</p>
                <p className="mt-1 text-[11px] text-white/45">{small}</p>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Pastga aylantirish ko'rsatkichi */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="absolute bottom-6 left-1/2 z-10 -translate-x-1/2"
        >
          <div className="flex h-9 w-6 items-start justify-center rounded-full border border-white/20 p-1.5">
            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}
              className="h-2 w-1 rounded-full bg-gold-400"
            />
          </div>
        </motion.div>
      </section>

      {/* ===== Reklama lentalari (marquee) ===== */}
      <section className="relative border-y border-gold-400/20 bg-gradient-to-r from-gold-400/[0.07] via-gold-400/[0.12] to-gold-400/[0.07] py-4">
        <div className="flex overflow-hidden">
          <div className="animate-marquee flex shrink-0 items-center gap-8 pr-8">
            {[...MARQUEE_ITEMS, ...MARQUEE_ITEMS, ...MARQUEE_ITEMS].map((text, i) => (
              <span
                key={i}
                className="flex items-center gap-8 whitespace-nowrap font-display text-sm font-bold tracking-wide text-gold-200"
              >
                {text}
                <Sparkles className="h-4 w-4 text-gold-400" />
              </span>
            ))}
          </div>
          <div aria-hidden className="animate-marquee flex shrink-0 items-center gap-8 pr-8">
            {[...MARQUEE_ITEMS, ...MARQUEE_ITEMS, ...MARQUEE_ITEMS].map((text, i) => (
              <span
                key={i}
                className="flex items-center gap-8 whitespace-nowrap font-display text-sm font-bold tracking-wide text-gold-200"
              >
                {text}
                <Sparkles className="h-4 w-4 text-gold-400" />
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ===== Imkoniyatlar ===== */}
      <section id="imkoniyatlar" className="relative mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-28">
        <motion.div {...fadeUp} transition={{ duration: 0.6 }} className="mb-12 text-center">
          <p className="mb-3 text-xs font-bold uppercase tracking-[0.25em] text-gold-400">
            Imkoniyatlar
          </p>
          <h2 className="font-display text-2xl font-extrabold sm:text-4xl">
            Bitta sayt — <span className="text-gold-gradient">barcha AI qurollar</span>
          </h2>
        </motion.div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <motion.div
              key={f.title}
              {...fadeUp}
              transition={{ duration: 0.55, delay: (i % 3) * 0.09 }}
              className="glass group rounded-3xl p-6 transition-colors hover:border-gold-400/30"
            >
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-gold-400/10 text-gold-400 transition-all group-hover:scale-110 group-hover:bg-gold-400/20">
                <f.icon className="h-6 w-6" />
              </div>
              <h3 className="font-display text-base font-bold">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-white/50">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ===== Qanday ishlaydi ===== */}
      <section id="qanday" className="relative border-y border-white/[0.06] bg-white/[0.015] py-20 sm:py-28">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <motion.div {...fadeUp} transition={{ duration: 0.6 }} className="mb-12 text-center">
            <p className="mb-3 text-xs font-bold uppercase tracking-[0.25em] text-gold-400">
              Qanday ishlaydi
            </p>
            <h2 className="font-display text-2xl font-extrabold sm:text-4xl">
              Atigi <span className="text-gold-gradient">3 qadam</span>
            </h2>
          </motion.div>

          <div className="grid gap-5 md:grid-cols-3">
            {STEPS.map((s, i) => (
              <motion.div
                key={s.n}
                {...fadeUp}
                transition={{ duration: 0.55, delay: i * 0.12 }}
                className="relative rounded-3xl border border-white/[0.07] bg-gradient-to-b from-white/[0.05] to-transparent p-7"
              >
                <span className="font-display text-5xl font-extrabold text-white/[0.07]">
                  {s.n}
                </span>
                <div className="mt-4 mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-gold-300 to-gold-600 text-ink-950">
                  <s.icon className="h-5 w-5" />
                </div>
                <h3 className="font-display text-base font-bold">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-white/50">{s.desc}</p>
              </motion.div>
            ))}
          </div>

          <motion.div
            {...fadeUp}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-10 flex items-center justify-center gap-2 text-center text-sm text-white/45"
          >
            <MonitorSmartphone className="h-4 w-4 shrink-0 text-gold-400" />
            Telefon, planshet yoki kompyuter — barcha qurilmada bir xil chiroyli ishlaydi
          </motion.div>
        </div>
      </section>

      {/* ===== Narxlar teaser (reklama) ===== */}
      <section id="narxlar" className="relative mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-28">
        <motion.div {...fadeUp} transition={{ duration: 0.6 }} className="mb-12 text-center">
          <p className="mb-3 text-xs font-bold uppercase tracking-[0.25em] text-gold-400">
            Narxlar
          </p>
          <h2 className="font-display text-2xl font-extrabold sm:text-4xl">
            <span className="text-gold-gradient">Bepul</span> boshlang, kerak bo'lsa kengayting
          </h2>
        </motion.div>

        <div className="grid gap-5 md:grid-cols-3">
          {[
            {
              name: "Dima Start",
              price: "0 so'm",
              period: "har doim bepul",
              icon: Sparkles,
              accent: false,
              points: ["3 ta AI chat", "Rasm yaratish (4K gacha)", "Kunlik bepul limitlar"],
            },
            {
              name: "Dima Pro",
              price: "50 000",
              period: "so'm / oy",
              icon: Zap,
              accent: true,
              points: ["Katta kunlik limitlar", "Ustuvor tezlik", "Yangi funksiyalarga erta kirish"],
            },
            {
              name: "Dima Turbo",
              price: "300 000",
              period: "so'm / yil",
              icon: Crown,
              accent: false,
              oldPrice: "600 000",
              points: ["Eng yuqori limitlar", "Shaxsiy qo'llab-quvvatlash", "300 000 so'm tejaysiz"],
            },
          ].map((p, i) => (
            <motion.div
              key={p.name}
              {...fadeUp}
              transition={{ duration: 0.55, delay: i * 0.1 }}
              className={`relative rounded-3xl p-6 ${
                p.accent
                  ? "border border-gold-400/40 bg-gradient-to-b from-gold-400/[0.12] to-white/[0.03] shadow-[0_20px_60px_rgba(245,192,68,0.15)]"
                  : "glass"
              }`}
            >
              {p.oldPrice && (
                <span className="absolute -top-3 right-5 flex items-center gap-1 rounded-full bg-gradient-to-r from-gold-300 to-gold-500 px-3 py-1 text-[11px] font-bold text-ink-950">
                  <BadgePercent className="h-3 w-3" /> -50%
                </span>
              )}
              <div
                className={`mb-4 flex h-11 w-11 items-center justify-center rounded-xl ${
                  p.accent
                    ? "bg-gradient-to-br from-gold-300 to-gold-600 text-ink-950"
                    : "bg-gold-400/10 text-gold-400"
                }`}
              >
                <p.icon className="h-5 w-5" />
              </div>
              <h3 className="font-display text-base font-bold">{p.name}</h3>
              <div className="mt-3 flex items-baseline gap-1.5">
                <span className="font-display text-3xl font-extrabold">{p.price}</span>
                <span className="text-xs text-white/40">{p.period}</span>
              </div>
              {p.oldPrice && (
                <p className="mt-1 text-sm text-white/35 line-through">{p.oldPrice} so'm</p>
              )}
              <ul className="mt-4 space-y-2">
                {p.points.map((pt) => (
                  <li key={pt} className="flex items-start gap-2 text-sm text-white/60">
                    <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-gold-400" />
                    {pt}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        <motion.div {...fadeUp} transition={{ duration: 0.6, delay: 0.25 }} className="mt-9 text-center">
          <p className="mx-auto mb-5 flex max-w-lg items-center justify-center gap-2 text-xs leading-relaxed text-white/45">
            <CreditCard className="h-4 w-4 shrink-0 text-gold-400" />
            To'lov karta orqali — chekni Telegram'ga yuborasiz, Premium emailingizga qo'lda yoqiladi
          </p>
          <Link
            href="/app?view=pricing"
            className="gold-focus inline-flex items-center gap-2 rounded-2xl border border-gold-400/40 bg-gold-400/10 px-7 py-3.5 text-sm font-bold text-gold-200 transition hover:bg-gold-400/20"
          >
            Batafsil narxlar
            <ArrowRight className="h-4 w-4" />
          </Link>
        </motion.div>
      </section>

      {/* ===== Yakuniy CTA ===== */}
      <section className="relative px-4 pb-24 sm:px-6">
        <motion.div
          {...fadeUp}
          transition={{ duration: 0.7 }}
          className="relative mx-auto max-w-4xl overflow-hidden rounded-[32px] border border-gold-400/25 bg-gradient-to-b from-gold-400/[0.12] to-transparent px-6 py-16 text-center sm:py-20"
        >
          <div className="pointer-events-none absolute -top-24 left-1/2 h-64 w-[520px] -translate-x-1/2 rounded-full bg-[radial-gradient(ellipse_at_center,rgba(245,192,68,0.25),transparent_70%)] blur-2xl" />
          <h2 className="relative font-display text-2xl font-extrabold sm:text-4xl">
            Hozir boshlang —<br className="sm:hidden" />
            <span className="text-gold-gradient"> bu bepul</span>
          </h2>
          <p className="relative mx-auto mt-4 max-w-md text-sm text-white/55">
            Karta ham, kalit ham shart emas. Email bilan kiring va o'zbek AI'dan to'liq
            foydalaning.
          </p>
          <Link
            href="/app"
            className="gold-focus group relative mt-8 inline-flex items-center gap-2 rounded-2xl bg-gradient-to-br from-gold-300 via-gold-400 to-gold-600 px-10 py-4 font-display text-sm font-bold text-ink-950 shadow-[0_14px_50px_rgba(245,192,68,0.5)] transition hover:brightness-110 active:scale-[0.98]"
          >
            <Send className="h-4 w-4" />
            Dima'AI ga kirish
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </motion.div>
      </section>

      {/* ===== Bog'lanish / Telegram ===== */}
      <section className="relative px-4 pb-20 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          className="mx-auto grid max-w-4xl gap-4 rounded-[32px] border border-white/10 bg-white/[0.03] p-6 sm:grid-cols-2 sm:p-8"
        >
          <a
            href={TELEGRAM.channel}
            target="_blank"
            rel="noreferrer"
            className="gold-focus group flex items-center gap-4 rounded-2xl border border-sky-400/20 bg-gradient-to-br from-sky-500/10 to-transparent p-5 transition hover:border-sky-400/50"
          >
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-sky-500 text-white shadow-[0_6px_20px_rgba(56,189,248,0.35)]">
              <Send className="h-6 w-6" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="font-display text-base font-bold text-white">Telegram kanal</p>
              <p className="truncate text-xs text-white/50">@dima_ai_offical · yangiliklar va e'lonlar</p>
            </div>
            <ArrowRight className="h-4 w-4 shrink-0 text-sky-300 transition-transform group-hover:translate-x-1" />
          </a>
          <a
            href={TELEGRAM.admin}
            target="_blank"
            rel="noreferrer"
            className="gold-focus group flex items-center gap-4 rounded-2xl border border-gold-400/30 bg-gradient-to-br from-gold-400/10 to-transparent p-5 transition hover:border-gold-400/60"
          >
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-gold-300 to-gold-600 text-ink-950 shadow-[0_6px_22px_rgba(245,192,68,0.35)]">
              <ShieldCheck className="h-6 w-6" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="font-display text-base font-bold text-white">Admin bilan bog'lanish</p>
              <p className="truncate text-xs text-white/50">@Dima_ai_admin · Premium, taklif va savollar</p>
            </div>
            <ArrowRight className="h-4 w-4 shrink-0 text-gold-300 transition-transform group-hover:translate-x-1" />
          </a>
        </motion.div>
      </section>

      {/* ===== Footer ===== */}
      <footer className="border-t border-white/[0.06] px-4 py-10 sm:px-6">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 text-center sm:flex-row sm:text-left">
          <div className="flex items-center gap-2.5">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-gold-300 to-gold-600 font-display text-sm font-extrabold text-ink-950">
              D
            </span>
            <div>
              <p className="font-display text-sm font-bold">
                Dima<span className="text-gold-gradient">'AI</span>
              </p>
              <p className="text-[11px] text-white/40">O'zbek tilidagi bepul AI platforma</p>
            </div>
          </div>
          <div className="flex flex-col items-center gap-2 text-xs text-white/40 sm:items-end">
            <p>Groq (chat) • Pollinations (rasm) orqali ishlaydi</p>
            <div className="flex items-center gap-3">
              <a
                href={TELEGRAM.channel}
                target="_blank"
                rel="noreferrer"
                className="text-sky-300 transition hover:text-sky-200"
              >
                Kanal
              </a>
              <span className="text-white/20">·</span>
              <a
                href={TELEGRAM.admin}
                target="_blank"
                rel="noreferrer"
                className="text-gold-300 transition hover:text-gold-200"
              >
                Admin
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
