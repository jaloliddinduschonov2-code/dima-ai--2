"use client";

import type { ReactNode } from "react";
import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowUp,
  Brain,
  Check,
  Copy,
  FileText,
  FileUp,
  History,
  Image as ImageIcon,
  LockKeyhole,
  Loader2,
  Paperclip,
  Plus,
  Presentation,
  RotateCcw,
  Sparkles,
  Trash2,
  X,
  Zap,
} from "lucide-react";
import type { PublicUser } from "@/lib/types";

type ChatId = "gemini-pro" | "gpt-astra-6" | "claude-opus";
type TemplateId = "normal" | "referat" | "slayd";
type AttKind = "image" | "file";

type Attachment = {
  id: string;
  kind: AttKind;
  filename: string;
  mimeType: string;
  size: number;
  /** image uchun data URL, file uchun extract qilingan matn */
  dataUrl: string;
};

type Msg = {
  id: string;
  role: "user" | "assistant";
  content: string;
  attachments?: Attachment[];
  streaming?: boolean;
  error?: boolean;
};

type HistoryItem = {
  id: string;
  chatId: ChatId;
  title: string;
  updatedAt: string;
};

const CHATS: {
  id: ChatId;
  label: string;
  sub: string;
  model: string;
  icon: typeof Sparkles;
  premium?: boolean;
}[] = [
  {
    id: "gemini-pro",
    label: "Gemini Pro",
    sub: "Kundalik yordamchi",
    model: "Groq tezligi",
    icon: Sparkles,
  },
  {
    id: "gpt-astra-6",
    label: "GPT Astra 6",
    sub: "Chuqur tafakkur",
    model: "OpenAI + zaxira",
    icon: Brain,
    premium: true,
  },
  {
    id: "claude-opus",
    label: "Claude Opus 5.5",
    sub: "Fayllar + rasmlar",
    model: "Vision + Fayl",
    icon: Zap,
    premium: true,
  },
];

const SUGGESTIONS: Record<ChatId, string[]> = {
  "gemini-pro": [
    "Sun'iy intellekt nima? Oddiy tilda tushuntir",
    "Tug'ilgan kun uchun chiroyli tabriknoma yoz",
    "Ingliz tilini tez o'rganishning 5 ta usuli",
    "Samarali kun tartibi tuzib ber",
  ],
  "gpt-astra-6": [
    "Onlayn biznes uchun qadam-baqadam reja",
    "Marketing strategiyasi: Instagram do'kon",
    "Ushbu masalani mantiqan yechib ber",
    "Murakkab tushunchani sodda tushuntir",
  ],
  "claude-opus": [
    "Rasm yuklayman, uni tasvirlab ber",
    "Fayl yuklayman, qisqacha xulosa qil",
    "Matndagi xatolarni to'g'rila",
    "Yuklangan rasm asosida retsept yoz",
  ],
};

const TEMPLATES: {
  id: TemplateId;
  label: string;
  hint: string;
  icon: typeof FileText;
  color: string;
}[] = [
  { id: "normal", label: "Oddiy", hint: "Suhbat", icon: Sparkles, color: "text-white/60" },
  {
    id: "referat",
    label: "Referat",
    hint: "Akademik yozuv",
    icon: FileText,
    color: "text-gold-300",
  },
  {
    id: "slayd",
    label: "Slayd",
    hint: "PowerPoint tayyor",
    icon: Presentation,
    color: "text-gold-300",
  },
];

let idCounter = 0;
const nextId = () => `m-${Date.now()}-${idCounter++}`;

/* ---------- Markdown renderer ---------- */

function renderInline(text: string, kp: string): ReactNode[] {
  const out: ReactNode[] = [];
  const re = /(\*\*[^*]+\*\*|`[^`\n]+`)/g;
  let last = 0;
  let i = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(text.slice(last, m.index));
    const tok = m[0];
    if (tok.startsWith("**")) {
      out.push(<strong key={`${kp}-b${i}`}>{tok.slice(2, -2)}</strong>);
    } else {
      out.push(<code key={`${kp}-c${i}`}>{tok.slice(1, -1)}</code>);
    }
    last = m.index + tok.length;
    i++;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

function Markdown({ text }: { text: string }) {
  const blocks: ReactNode[] = [];
  const segments = text.split("```");
  segments.forEach((seg, si) => {
    if (si % 2 === 1) {
      const nl = seg.indexOf("\n");
      const code = (nl === -1 ? seg : seg.slice(nl + 1)).replace(/\n$/, "");
      blocks.push(
        <pre key={`pre-${si}`}>
          <code>{code}</code>
        </pre>,
      );
      return;
    }
    let listType: "ul" | "ol" | null = null;
    let listItems: string[] = [];
    let keyI = 0;
    const flushList = () => {
      if (!listType) return;
      const items = listItems.map((it, ii) => (
        <li key={`li-${ii}`}>{renderInline(it, `li-${si}-${ii}`)}</li>
      ));
      blocks.push(
        listType === "ul" ? (
          <ul key={`ul-${si}-${keyI++}`}>{items}</ul>
        ) : (
          <ol key={`ol-${si}-${keyI++}`}>{items}</ol>
        ),
      );
      listType = null;
      listItems = [];
    };
    seg.split("\n").forEach((line, li) => {
      const t = line.trim();
      const isUl = /^[-*•]\s+/.test(t);
      const isOl = /^\d+[.)]\s+/.test(t);
      if (isUl || isOl) {
        const type = isUl ? "ul" : "ol";
        if (listType !== type) flushList();
        listType = type;
        listItems.push(t.replace(/^([-*•]|\d+[.)])\s+/, ""));
        return;
      }
      flushList();
      if (!t) return;
      if (t.startsWith("### ")) {
        blocks.push(<h3 key={`h-${si}-${li}`}>{renderInline(t.slice(4), `h-${si}-${li}`)}</h3>);
      } else if (t.startsWith("## ")) {
        blocks.push(<h2 key={`h-${si}-${li}`}>{renderInline(t.slice(3), `h-${si}-${li}`)}</h2>);
      } else if (t.startsWith("# ")) {
        blocks.push(<h1 key={`h-${si}-${li}`}>{renderInline(t.slice(2), `h-${si}-${li}`)}</h1>);
      } else {
        blocks.push(<p key={`p-${si}-${li}`}>{renderInline(t, `p-${si}-${li}`)}</p>);
      }
    });
    flushList();
  });
  return <div className="chat-md text-[15px] leading-relaxed">{blocks}</div>;
}

function formatBytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

/* ---------- Asosiy panel ---------- */

export default function ChatPanel({
  user,
  onPricing,
}: {
  user: PublicUser | null;
  onPricing: () => void;
}) {
  const [active, setActive] = useState<ChatId>("gemini-pro");
  const [template, setTemplate] = useState<TemplateId>("normal");
  const [store, setStore] = useState<Record<ChatId, Msg[]>>({
    "gemini-pro": [],
    "gpt-astra-6": [],
    "claude-opus": [],
  });
  const [conversationIds, setConversationIds] = useState<Record<ChatId, string | null>>({
    "gemini-pro": null,
    "gpt-astra-6": null,
    "claude-opus": null,
  });
  const [historyItems, setHistoryItems] = useState<HistoryItem[]>([]);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [input, setInput] = useState("");
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [sending, setSending] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const imgRef = useRef<HTMLInputElement>(null);

  const messages = store[active];
  const activeMeta = CHATS.find((c) => c.id === active)!;

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, active, attachments.length]);

  async function loadHistory() {
    if (!user) return;
    setHistoryLoading(true);
    try {
      const res = await fetch("/api/history", { cache: "no-store" });
      const data = await res.json();
      if (res.ok) setHistoryItems(data.conversations ?? []);
    } catch {
      // tarix yuklanmasa chat ishlashda davom etadi
    }
    setHistoryLoading(false);
  }

  useEffect(() => {
    if (user) loadHistory();
    else setHistoryItems([]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  function newChat(chatId: ChatId = active) {
    setStore((s) => ({ ...s, [chatId]: [] }));
    setConversationIds((s) => ({ ...s, [chatId]: null }));
    setAttachments([]);
    setInput("");
    setHistoryOpen(false);
  }

  async function openHistory(id: string) {
    setHistoryLoading(true);
    try {
      const res = await fetch(`/api/history?id=${encodeURIComponent(id)}`, { cache: "no-store" });
      const data = await res.json();
      if (res.ok) {
        const chatId = data.conversation.chatId as ChatId;
        if (!CHATS.some((c) => c.id === chatId)) return;
        const loaded: Msg[] = (data.messages ?? []).map(
          (m: { id: string; role: string; content: string }) => ({
            id: m.id,
            role: m.role === "assistant" ? "assistant" : "user",
            content: m.content,
          }),
        );
        setActive(chatId);
        setStore((s) => ({ ...s, [chatId]: loaded }));
        setConversationIds((s) => ({ ...s, [chatId]: id }));
        setHistoryOpen(false);
      }
    } finally {
      setHistoryLoading(false);
    }
  }

  async function deleteHistory(id: string) {
    await fetch(`/api/history?id=${encodeURIComponent(id)}`, { method: "DELETE" }).catch(() => {});
    setHistoryItems((items) => items.filter((x) => x.id !== id));
    const chatId = (Object.keys(conversationIds) as ChatId[]).find(
      (key) => conversationIds[key] === id,
    );
    if (chatId) newChat(chatId);
  }

  function selectChat(c: (typeof CHATS)[number]) {
    const canUsePremium =
      user && (user.role === "admin" || user.plan === "pro" || user.plan === "turbo");
    if (c.premium && !canUsePremium) {
      onPricing();
      return;
    }
    setActive(c.id);
  }

  function patchMessage(chatId: ChatId, id: string, patch: Partial<Msg>) {
    setStore((s) => ({
      ...s,
      [chatId]: s[chatId].map((m) => (m.id === id ? { ...m, ...patch } : m)),
    }));
  }

  async function addFiles(files: FileList | null, kind: AttKind) {
    if (!files || files.length === 0) return;
    const arr: Attachment[] = [];
    for (const f of Array.from(files)) {
      if (f.size > 6 * 1024 * 1024) {
        alert(`"${f.name}" juda katta (maksimum 6 MB). Kichikroq fayl yuboring.`);
        continue;
      }
      const id = `att-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      if (kind === "image") {
        const dataUrl = await new Promise<string>((res, rej) => {
          const r = new FileReader();
          r.onload = () => res(String(r.result));
          r.onerror = rej;
          r.readAsDataURL(f);
        });
        arr.push({
          id,
          kind: "image",
          filename: f.name,
          mimeType: f.type || "image/jpeg",
          size: f.size,
          dataUrl,
        });
      } else {
        const txt = await new Promise<string>((res, rej) => {
          const r = new FileReader();
          r.onload = () => res(String(r.result ?? ""));
          r.onerror = rej;
          r.readAsText(f);
        }).catch(() => "");
        if (!txt.trim()) {
          alert(`"${f.name}" faylini o'qib bo'lmadi. Faqat matnli fayllar (.txt, .md, .csv, .json, .py, .html, .css, .js va h.k.) qo'llab-quvvatlanadi.`);
          continue;
        }
        arr.push({
          id,
          kind: "file",
          filename: f.name,
          mimeType: f.type || "text/plain",
          size: f.size,
          dataUrl: txt,
        });
      }
    }
    setAttachments((prev) => [...prev, ...arr]);
  }

  function removeAttachment(id: string) {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  }

  async function send(chatId: ChatId, text: string) {
    const content = text.trim();
    if (!content && attachments.length === 0) return;
    if (sending) return;
    setSending(true);
    setInput("");
    const sentAttachments = [...attachments];
    setAttachments([]);
    if (taRef.current) taRef.current.style.height = "auto";

    const history = store[chatId];
    const userMsg: Msg = {
      id: nextId(),
      role: "user",
      content: content || "(fayl yuborildi)",
      attachments: sentAttachments,
    };
    const botMsg: Msg = { id: nextId(), role: "assistant", content: "", streaming: true };
    setStore((s) => ({ ...s, [chatId]: [...s[chatId], userMsg, botMsg] }));

    // API uchun yagona formatga keltirish
    const msgToApi = (m: Msg, isLast = false) => ({
      role: m.role,
      content: m.role === "user" && m.content === "(fayl yuborildi)" ? "" : m.content,
      attachments: (m.attachments ?? []).map((a) => ({
        kind: a.kind,
        filename: a.filename,
        mimeType: a.mimeType,
        // Oxirgi user xabari (yangi yuklangan) — to'liq, oldingilari — qisqargan
        content: a.kind === "file" && !isLast ? a.dataUrl.slice(0, 3000) : a.dataUrl,
      })),
    });

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat: chatId,
          conversationId: conversationIds[chatId],
          template: template === "normal" ? null : template,
          messages: [
            ...history.slice(-7).map((m) => msgToApi(m)),
            msgToApi(userMsg, true),
          ],
        }),
      });

      if (!res.ok || !res.body) {
        let errText = "Server xatosi";
        try {
          const data = await res.json();
          errText = data.error ?? errText;
        } catch {
          /* json emas */
        }
        patchMessage(chatId, botMsg.id, { content: errText, streaming: false, error: true });
        if (res.status === 403) onPricing();
        setSending(false);
        return;
      }

      const newConversationId = res.headers.get("X-Conversation-Id");
      if (newConversationId) {
        setConversationIds((s) => ({ ...s, [chatId]: newConversationId }));
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let acc = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        acc += decoder.decode(value, { stream: true });
        patchMessage(chatId, botMsg.id, { content: acc });
      }
      patchMessage(chatId, botMsg.id, { streaming: false });
      if (user) loadHistory();
    } catch {
      patchMessage(chatId, botMsg.id, {
        content: "Ulanish xatosi. Internetni tekshirib, qayta urinib ko'ring.",
        streaming: false,
        error: true,
      });
    }
    setSending(false);
  }

  function copyMessage(m: Msg) {
    navigator.clipboard?.writeText(m.content).catch(() => {});
    setCopiedId(m.id);
    setTimeout(() => setCopiedId((c) => (c === m.id ? null : c)), 1500);
  }

  const suggestionText =
    template === "referat"
      ? "Mavzuni yozing (masalan: «O'zbekistonda kichik biznesning rivojlanishi»)"
      : template === "slayd"
        ? "Taqdimot mavzusini yozing (masalan: «Ekologiya va kelajak»)"
        : attachments.length > 0
          ? "Fayl bilan nima qilish kerakligini yozing…"
          : "Xabar yozing… (Enter — yuborish)";

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col">
      {/* AI tanlov */}
      <div className="px-4 pt-4 sm:px-6">
        <div className="mx-auto mb-2 flex max-w-2xl items-center justify-between gap-2">
          <button
            onClick={() => newChat()}
            className="gold-focus flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.04] px-3 py-2 text-xs font-bold text-white/65 transition hover:border-gold-400/40 hover:text-gold-300"
          >
            <Plus className="h-3.5 w-3.5" /> Yangi suhbat
          </button>
          <button
            onClick={() => {
              if (!user) return;
              setHistoryOpen(true);
              loadHistory();
            }}
            disabled={!user}
            className="gold-focus flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.04] px-3 py-2 text-xs font-bold text-white/65 transition hover:border-gold-400/40 hover:text-gold-300 disabled:opacity-35"
            title={user ? "Saqlangan suhbatlar" : "Tarix uchun avval kiring"}
          >
            <History className="h-3.5 w-3.5" /> Tarix
          </button>
        </div>
        <div className="glass mx-auto flex max-w-2xl gap-1 rounded-2xl p-1.5">
          {CHATS.map((c) => {
            const Icon = c.icon;
            const isActive = c.id === active;
            const locked = Boolean(
              c.premium &&
                !(user && (user.role === "admin" || user.plan === "pro" || user.plan === "turbo")),
            );
            return (
              <button
                key={c.id}
                onClick={() => selectChat(c)}
                className={`gold-focus relative flex-1 rounded-xl px-2 py-2.5 text-center transition-colors sm:px-4 ${
                  isActive ? "text-ink-950" : "text-white/70 hover:text-white"
                }`}
              >
                {isActive && (
                  <motion.span
                    layoutId="chat-tab"
                    className="absolute inset-0 rounded-xl bg-gradient-to-br from-gold-300 via-gold-400 to-gold-600 shadow-[0_4px_24px_rgba(245,192,68,0.35)]"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.55 }}
                  />
                )}
                <span className="relative z-10 flex flex-col items-center justify-center gap-0.5">
                  <span className="flex items-center gap-1.5">
                    <Icon className="h-4 w-4" />
                    <span className="font-display text-[10px] font-bold sm:text-sm">{c.label}</span>
                    {locked && <LockKeyhole className="h-3 w-3 text-gold-400" />}
                  </span>
                  <span className={`hidden text-[10px] sm:inline ${isActive ? "text-ink-950/70" : "text-white/40"}`}>
                    {locked ? "Premium" : c.sub}
                  </span>
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Xabarlar */}
      <div ref={scrollRef} className="min-h-0 flex-1 overflow-y-auto px-4 py-6 sm:px-6">
        <div className="mx-auto max-w-2xl">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center pt-4 text-center sm:pt-10">
              <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
                <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-gold-300 to-gold-600 shadow-[0_8px_40px_rgba(245,192,68,0.4)]">
                  <activeMeta.icon className="h-8 w-8 text-ink-950" />
                </div>
                <h2 className="font-display text-xl font-bold sm:text-2xl">
                  Assalomu alaykum! <span className="text-gold-gradient">{activeMeta.label}</span>
                </h2>
                <p className="mt-2 max-w-sm text-sm text-white/50">{activeMeta.sub} — o'zbek tilida javob beradi.</p>
              </motion.div>

              {/* Shablonlar */}
              <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
                {TEMPLATES.map((t) => {
                  const Icon = t.icon;
                  const on = template === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setTemplate(t.id)}
                      className={`gold-focus flex items-center gap-2 rounded-full px-4 py-2 text-xs font-bold transition-all ${
                        on
                          ? "bg-gradient-to-br from-gold-300 to-gold-600 text-ink-950 shadow-[0_6px_20px_rgba(245,192,68,0.35)]"
                          : "border border-white/10 bg-white/[0.04] text-white/60 hover:text-white"
                      }`}
                    >
                      <Icon className="h-3.5 w-3.5" />
                      {t.label}
                      <span className={`text-[10px] ${on ? "text-ink-950/70" : "text-white/35"}`}>
                        · {t.hint}
                      </span>
                    </button>
                  );
                })}
              </div>

              <div className="mt-6 grid w-full max-w-lg grid-cols-1 gap-2 sm:grid-cols-2">
                {SUGGESTIONS[active].map((s, i) => (
                  <motion.button
                    key={s}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.12 + i * 0.06 }}
                    onClick={() => send(active, s)}
                    className="glass gold-focus rounded-xl px-4 py-3 text-left text-sm text-white/75 transition-all hover:border-gold-400/40 hover:bg-white/[0.07] hover:text-white"
                  >
                    {s}
                  </motion.button>
                ))}
              </div>
            </div>
          ) : (
            <AnimatePresence initial={false}>
              {messages.map((m) => (
                <motion.div
                  key={m.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.25 }}
                  className={`mb-4 flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`group relative w-full max-w-[88%] rounded-2xl px-4 py-3 sm:max-w-[80%] ${
                      m.role === "user"
                        ? "ml-auto bg-gradient-to-br from-gold-400 to-gold-600 text-ink-950 shadow-[0_6px_24px_rgba(245,192,68,0.25)]"
                        : m.error
                          ? "border border-red-400/30 bg-red-500/10 text-red-200"
                          : "glass"
                    }`}
                  >
                    {m.role === "user" ? (
                      <div>
                        {m.attachments && m.attachments.length > 0 && (
                          <div className="mb-2 flex flex-wrap gap-2">
                            {m.attachments.map((a) =>
                              a.kind === "image" ? (
                                <img
                                  key={a.id}
                                  src={a.dataUrl}
                                  alt={a.filename}
                                  className="max-h-56 max-w-full rounded-lg border border-black/20 object-cover"
                                />
                              ) : (
                                <div
                                  key={a.id}
                                  className="flex items-center gap-2 rounded-lg border border-black/20 bg-black/15 px-2.5 py-1.5 text-xs font-medium text-ink-950"
                                >
                                  <FileText className="h-4 w-4" />
                                  <span className="max-w-[140px] truncate">{a.filename}</span>
                                </div>
                              ),
                            )}
                          </div>
                        )}
                        {m.content && m.content !== "(fayl yuborildi)" && (
                          <p className="whitespace-pre-wrap text-[15px] font-medium leading-relaxed">
                            {m.content}
                          </p>
                        )}
                      </div>
                    ) : m.error ? (
                      <div className="text-sm">
                        <p>{m.content}</p>
                        <button
                          onClick={() => {
                            const lastUser = [...messages].reverse().find((x) => x.role === "user");
                            setStore((s) => ({
                              ...s,
                              [active]: s[active].filter((x) => x.id !== m.id),
                            }));
                            if (lastUser) {
                              setAttachments(lastUser.attachments ?? []);
                              setInput(lastUser.content === "(fayl yuborildi)" ? "" : lastUser.content);
                            }
                          }}
                          className="mt-2 inline-flex items-center gap-1.5 rounded-lg bg-red-400/15 px-3 py-1.5 text-xs font-semibold text-red-200 transition hover:bg-red-400/25"
                        >
                          <RotateCcw className="h-3.5 w-3.5" /> Qayta urinish
                        </button>
                      </div>
                    ) : (
                      <>
                        {m.content ? <Markdown text={m.content} /> : null}
                        {m.streaming && (
                          <span className="ml-0.5 inline-block h-4 w-2 animate-caret rounded-sm bg-gold-400 align-middle" />
                        )}
                        {!m.streaming && m.content && (
                          <button
                            onClick={() => copyMessage(m)}
                            className="absolute -right-2 -top-2 hidden rounded-lg border border-white/10 bg-ink-800 p-1.5 text-white/50 opacity-0 shadow-lg transition group-hover:opacity-100 hover:text-gold-300 sm:block"
                            title="Nusxalash"
                          >
                            {copiedId === m.id ? (
                              <Check className="h-3.5 w-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="h-3.5 w-3.5" />
                            )}
                          </button>
                        )}
                      </>
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          )}
        </div>
      </div>

      {/* Yozish maydoni */}
      <div className="px-4 pb-4 sm:px-6 sm:pb-6">
        {/* Biriktirilgan fayllar preview */}
        {attachments.length > 0 && (
          <div className={`mx-auto mb-2 flex max-w-2xl gap-2 overflow-x-auto rounded-2xl p-2 ${attachments.some((a) => a.kind === "image") ? "glass" : ""}`}>
            {attachments.map((a) => (
              <div key={a.id} className="relative shrink-0">
                {a.kind === "image" ? (
                  <img
                    src={a.dataUrl}
                    alt={a.filename}
                    className="h-20 w-20 rounded-xl border border-white/10 object-cover"
                  />
                ) : (
                  <div className="flex h-20 w-44 flex-col justify-center gap-1 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                    <div className="flex items-center gap-2 text-xs font-semibold text-white/80">
                      <FileText className="h-4 w-4 text-gold-400" />
                      <span className="truncate">{a.filename}</span>
                    </div>
                    <span className="text-[10px] text-white/40">{formatBytes(a.size)} · matnli fayl</span>
                  </div>
                )}
                <button
                  onClick={() => removeAttachment(a.id)}
                  className="absolute -right-1.5 -top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-ink-900 text-white shadow-md ring-1 ring-white/20 transition hover:bg-red-500 hover:text-white"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="glass mx-auto flex max-w-2xl flex-col gap-2 rounded-2xl p-2 shadow-[0_10px_40px_rgba(0,0,0,0.45)]">
          {/* Tez shablonlar (faqat xabarlar bo'sa bo'lmaganda) — xabar yozilayotganda ixcham tugma */}
          {messages.length > 0 && (
            <div className="flex items-center gap-1 px-1 pt-1">
              <span className="mr-1 text-[10px] font-bold uppercase tracking-wider text-white/35">Rejim:</span>
              {TEMPLATES.map((t) => {
                const Icon = t.icon;
                const on = template === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => setTemplate(t.id)}
                    className={`gold-focus flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-bold transition ${
                      on ? "bg-gold-400/20 text-gold-300" : "text-white/50 hover:bg-white/5 hover:text-white"
                    }`}
                  >
                    <Icon className="h-3 w-3" /> {t.label}
                  </button>
                );
              })}
            </div>
          )}

          <div className="flex items-end gap-2">
            <textarea
              ref={taRef}
              value={input}
              onChange={(e) => {
                setInput(e.target.value);
                e.target.style.height = "auto";
                e.target.style.height = Math.min(e.target.scrollHeight, 160) + "px";
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send(active, input);
                }
              }}
              rows={1}
              placeholder={suggestionText}
              className="max-h-[160px] flex-1 resize-none bg-transparent px-3 py-2.5 text-[15px] text-white placeholder:text-white/35 focus:outline-none"
            />
            <div className="flex shrink-0 flex-col gap-1.5 pb-1 pr-1">
              <div className="flex gap-1">
                <button
                  onClick={() => imgRef.current?.click()}
                  disabled={sending}
                  className="gold-focus flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-white/55 transition hover:border-gold-400/40 hover:text-gold-300 disabled:opacity-40"
                  title="Rasm yuklash (vision)"
                >
                  <ImageIcon className="h-4 w-4" />
                </button>
                <button
                  onClick={() => fileRef.current?.click()}
                  disabled={sending}
                  className="gold-focus flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-white/55 transition hover:border-gold-400/40 hover:text-gold-300 disabled:opacity-40"
                  title="Matnli fayl yuklash (.txt, .md, .py, .csv…)"
                >
                  <Paperclip className="h-4 w-4" />
                </button>
              </div>
              <button
                onClick={() => send(active, input)}
                disabled={(!input.trim() && attachments.length === 0) || sending}
                className="gold-focus flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-gold-300 to-gold-600 text-ink-950 shadow-[0_4px_16px_rgba(245,192,68,0.4)] transition-all hover:scale-105 active:scale-95 disabled:opacity-35 disabled:hover:scale-100"
                aria-label="Yuborish"
              >
                <ArrowUp className="h-5 w-5" strokeWidth={2.5} />
              </button>
            </div>
          </div>
        </div>

        <input
          ref={fileRef}
          type="file"
          accept=".txt,.md,.markdown,.csv,.json,.py,.js,.ts,.tsx,.jsx,.html,.css,.xml,.yml,.yaml,.ini,.log,.rtf"
          multiple
          hidden
          onChange={(e) => {
            addFiles(e.target.files, "file");
            e.target.value = "";
          }}
        />
        <input
          ref={imgRef}
          type="file"
          accept="image/*"
          multiple
          hidden
          onChange={(e) => {
            addFiles(e.target.files, "image");
            e.target.value = "";
          }}
        />

        <div className="mt-2 flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-[10px] text-white/30">
          <span className="inline-flex items-center gap-1">
            <FileUp className="h-3 w-3" /> 6 MB gacha
          </span>
          <span>Rasm yuklash — AI ko'radi</span>
          <span>Matnli fayllar — AI o'qiydi</span>
        </div>
      </div>

      <AnimatePresence>
        {historyOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[65] flex justify-end bg-black/60 backdrop-blur-sm"
            onClick={() => setHistoryOpen(false)}
          >
            <motion.aside
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", bounce: 0.12, duration: 0.5 }}
              onClick={(e) => e.stopPropagation()}
              className="h-full w-full max-w-sm border-l border-white/10 bg-ink-900/95 p-4 shadow-2xl"
            >
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h3 className="font-display font-bold">Suhbatlar tarixi</h3>
                  <p className="text-xs text-white/40">Faqat siz ko'ra olasiz</p>
                </div>
                <button onClick={() => setHistoryOpen(false)} className="rounded-lg p-2 text-white/50 hover:bg-white/10 hover:text-white"><X className="h-5 w-5" /></button>
              </div>
              <button onClick={() => newChat()} className="mb-3 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-gold-300 to-gold-600 px-4 py-3 text-sm font-bold text-ink-950"><Plus className="h-4 w-4" /> Yangi suhbat</button>
              <div className="h-[calc(100%-112px)] space-y-2 overflow-y-auto pb-8">
                {historyLoading && historyItems.length === 0 ? (
                  <div className="py-12 text-center"><Loader2 className="mx-auto h-6 w-6 animate-spin text-gold-400" /></div>
                ) : historyItems.length === 0 ? (
                  <p className="py-12 text-center text-sm text-white/40">Hali saqlangan suhbat yo'q</p>
                ) : historyItems.map((item) => {
                  const meta = CHATS.find((c) => c.id === item.chatId);
                  return (
                    <div key={item.id} className="group flex items-center gap-2 rounded-xl border border-white/[0.07] bg-white/[0.03] p-2 transition hover:border-gold-400/30">
                      <button onClick={() => openHistory(item.id)} className="min-w-0 flex-1 px-2 py-1 text-left">
                        <p className="truncate text-sm font-semibold text-white/85">{item.title}</p>
                        <p className="mt-1 text-[10px] text-white/35">{meta?.label ?? "AI"} · {new Date(item.updatedAt).toLocaleDateString("uz-UZ")}</p>
                      </button>
                      <button onClick={() => deleteHistory(item.id)} className="rounded-lg p-2 text-white/30 transition hover:bg-red-500/10 hover:text-red-300" title="O'chirish"><Trash2 className="h-4 w-4" /></button>
                    </div>
                  );
                })}
              </div>
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
