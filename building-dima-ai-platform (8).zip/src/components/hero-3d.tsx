"use client";

import { useMemo, useRef, useState, useEffect } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";

/** Oltin zarralar galaktikasi — sekin aylanuvchi 3D halqa */
function Particles({ count }: { count: number }) {
  const ref = useRef<THREE.Points>(null);

  const { positions, colors } = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const gold = new THREE.Color("#f5c044");
    const light = new THREE.Color("#ffe9a8");
    const violet = new THREE.Color("#8b7bff");
    for (let i = 0; i < count; i++) {
      const r = 5 + Math.random() * 15;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta) * 0.55;
      positions[i * 3 + 2] = r * Math.cos(phi);
      const roll = Math.random();
      const c = roll > 0.86 ? violet : roll > 0.55 ? light : gold;
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;
    }
    return { positions, colors };
  }, [count]);

  useFrame((state, delta) => {
    const p = ref.current;
    if (!p) return;
    p.rotation.y += delta * 0.045;
    p.rotation.x = Math.sin(state.clock.elapsedTime * 0.12) * 0.07;
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        <bufferAttribute attach="attributes-color" args={[colors, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.06}
        vertexColors
        transparent
        opacity={0.85}
        sizeAttenuation
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

/** Markaziy puls qiluvchi oltin karkas */
function Core() {
  const outer = useRef<THREE.Mesh>(null);
  const inner = useRef<THREE.Mesh>(null);
  useFrame((state, delta) => {
    if (outer.current) {
      outer.current.rotation.x += delta * 0.1;
      outer.current.rotation.y += delta * 0.14;
      const s = 1 + Math.sin(state.clock.elapsedTime * 0.7) * 0.035;
      outer.current.scale.setScalar(s);
    }
    if (inner.current) {
      inner.current.rotation.x -= delta * 0.07;
      inner.current.rotation.y -= delta * 0.1;
    }
  });
  return (
    <>
      <mesh ref={outer}>
        <icosahedronGeometry args={[2.9, 1]} />
        <meshBasicMaterial wireframe color="#f5c044" transparent opacity={0.2} />
      </mesh>
      <mesh ref={inner}>
        <icosahedronGeometry args={[1.9, 0]} />
        <meshBasicMaterial wireframe color="#ffe08a" transparent opacity={0.1} />
      </mesh>
    </>
  );
}

/** Sichqoncha/barmoq harakatiga ergashuvchi kamera (parallaks) */
function Rig() {
  useFrame((state) => {
    const { camera, pointer, clock } = state;
    const t = clock.elapsedTime;
    const targetX = pointer.x * 1.3 + Math.sin(t * 0.18) * 0.5;
    const targetY = pointer.y * 0.8 + Math.cos(t * 0.15) * 0.35;
    camera.position.x = THREE.MathUtils.lerp(camera.position.x, targetX, 0.035);
    camera.position.y = THREE.MathUtils.lerp(camera.position.y, targetY, 0.035);
    camera.lookAt(0, 0, 0);
  });
  return null;
}

export default function Hero3D() {
  const [count, setCount] = useState(2400);

  useEffect(() => {
    // Telefonlarda yengilroq rejim
    if (window.innerWidth < 768) setCount(1300);
  }, []);

  return (
    <div className="absolute inset-0" aria-hidden>
      <Canvas
        dpr={[1, 1.8]}
        camera={{ position: [0, 0, 13], fov: 55 }}
        gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
      >
        <fog attach="fog" args={["#070709", 15, 34]} />
        <Particles count={count} />
        <Core />
        <Rig />
      </Canvas>
      {/* Matn o'qilishi uchun yumshoq qoplama */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_30%,rgba(7,7,9,0.55)_78%,#070709_100%)]" />
    </div>
  );
}
