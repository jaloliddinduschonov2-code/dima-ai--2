"use client";

import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Crown,
  FileText,
  Image as ImageIcon,
  LayoutDashboard,
  LogOut,
  MessageSquare,
  Presentation,
  ShieldCheck,
  Sparkles,
  User as UserIcon,
} from "lucide-react";
import Background from "@/components/background";
import ChatPanel from "@/components/chat-panel";
import ImageStudio from "@/components/image-studio";
import PricingView from "@/components/pricing-view";
import AdminPanel from "@/components/admin-panel";
import DocumentStudio from "@/components/document-studio";
import AuthDialog from "@/components/auth-dialog";
import { PLAN_NAMES, type PublicUser } from "@/lib/types";

type View = "chat" | "image" | "slides" | "report" | "pricing" | "admin";

const BASE_NAV: { id: View; label: string; icon: typeof MessageSquare }[] = [
  { id: "chat", label: "Suhbat", icon: MessageSquare },
  { id: "image", label: "Rasm", icon: ImageIcon },
  { id: "slides", label: "Slayd", icon: Presentation },
  { id: "report", label: "Referat", icon: FileText },
  { id: "pricing", label: "Narxlar", icon: Crown },
];

export default function AppShell({ initialView = "chat" }: { initialView?: View }) {
  const [view, setView] = useState<View>(initialView);
  const [user, setUser] = useState<PublicUser | null>(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  useEffect(() => {
    let cancelled = false;
    // URL dagi ?auth= holatlar (Google callback)
    const params = new URLSearchParams(window.location.search);
    const authParam = params.get("auth");

    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => {
        if (cancelled) return;
        setUser(d.user ?? null);
        if (view === "admin" && d.user?.role !== "admin") setView("chat");
        if (d.user && authParam) {
          // Auth bo'ldi — query paramni tozalaymiz
          window.history.replaceState({}, "", window.location.pathname);
        }
        if (!d.user && authParam && authParam !== "ok") {
          // Google kirish muvaffaqiyatsiz
          alert(
            authParam === "not-configured"
              ? "Google orqali kirish hozircha sozlanmagan. Email/parol bilan kiring."
              : authParam === "state-error"
                ? "Xavfsizlik tekshiruvi o'tmadi. Qayta urinib ko'ring."
                : "Google orqali kirishda xatolik. Email/parol bilan kiring.",
          );
        }
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" }).catch(() => {});
    setUser(null);
    setUserMenuOpen(false);
    if (view === "admin") setView("chat");
  }

  const isAdmin = user?.role === "admin";
  const NAV = useMemo(
    () => [
      ...BASE_NAV,
      ...(isAdmin
        ? [{ id: "admin" as View, label: "Admin", icon: LayoutDashboard }]
        : []),
    ],
    [isAdmin],
  );

  return (
    <div className="relative z-10 flex h-dvh flex-col">
      <Background />

      {/* Yuqori panel */}
      <header className="relative z-20 border-b border-white/[0.06] bg-ink-950/70 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          {/* Logotip */}
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-gold-300 via-gold-400 to-gold-600 font-display text-lg font-extrabold text-ink-950 shadow-[0_4px_20px_rgba(245,192,68,0.4)]">
              D
            </div>
            <div className="leading-tight">
              <p className="font-display text-[15px] font-bold">
                Dima<span className="text-gold-gradient">'AI</span>
              </p>
              <p className="text-[10px] text-white/40">bepul AI platforma</p>
            </div>
            <span className="ml-1 hidden rounded-full border border-gold-400/40 bg-gold-400/10 px-2 py-0.5 text-[10px] font-bold text-gold-300 sm:inline">
              BETA
            </span>
          </div>

          {/* Desktop navigatsiya */}
          <nav className="hidden items-center gap-1 rounded-full border border-white/[0.07] bg-white/[0.03] p-1 md:flex">
            {NAV.map((n) => {
              const Icon = n.icon;
              const on = view === n.id;
              return (
                <button
                  key={n.id}
                  onClick={() => setView(n.id)}
                  className={`gold-focus relative flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
                    on ? "text-ink-950" : "text-white/60 hover:text-white"
                  }`}
                >
                  {on && (
                    <motion.span
                      layoutId="nav-pill"
                      className="absolute inset-0 rounded-full bg-gradient-to-br from-gold-300 to-gold-600 shadow-[0_3px_16px_rgba(245,192,68,0.35)]"
                      transition={{ type: "spring", bounce: 0.2, duration: 0.5 }}
                    />
                  )}
                  <Icon className="relative z-10 h-4 w-4" />
                  <span className="relative z-10">{n.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Foydalanuvchi */}
          <div className="flex items-center gap-2">
            {!user ? (
              <button
                onClick={() => setAuthOpen(true)}
                className="gold-focus flex items-center gap-2 rounded-xl bg-gradient-to-br from-gold-300 to-gold-600 px-4 py-2.5 text-sm font-bold text-ink-950 shadow-[0_4px_20px_rgba(245,192,68,0.35)] transition hover:brightness-110 active:scale-95"
              >
                <UserIcon className="h-4 w-4" />
                <span className="hidden sm:inline">Kirish</span>
              </button>
            ) : (
              <div className="relative">
                <button
                  onClick={() => setUserMenuOpen((v) => !v)}
                  className="gold-focus flex items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.04] py-1.5 pl-1.5 pr-3 transition hover:border-gold-400/40"
                >
                  <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-gold-300 to-gold-600 font-display text-sm font-extrabold text-ink-950">
                    {(user.name || user.email)[0].toUpperCase()}
                  </span>
                  <span className="hidden text-left sm:block">
                    <span className="block max-w-[110px] truncate text-xs font-bold leading-tight">
                      {user.name || user.email.split("@")[0]}
                    </span>
                    <span
                      className={`block text-[10px] font-semibold ${
                        user.plan === "start" ? "text-white/40" : "text-gold-300"
                      }`}
                    >
                      {PLAN_NAMES[user.plan] ?? "Dima Start"}
                    </span>
                  </span>
                </button>

                <AnimatePresence>
                  {userMenuOpen && (
                    <>
                      <div
                        className="fixed inset-0 z-30"
                        onClick={() => setUserMenuOpen(false)}
                      />
                      <motion.div
                        initial={{ opacity: 0, y: 8, scale: 0.96 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 8, scale: 0.96 }}
                        transition={{ duration: 0.15 }}
                        className="glass absolute right-0 z-40 mt-2 w-60 rounded-2xl bg-ink-900/95 p-2 shadow-2xl"
                      >
                        <div className="mb-1 rounded-xl border border-white/[0.06] bg-white/[0.03] px-3.5 py-3">
                          <p className="truncate text-sm font-bold">{user.email}</p>
                          <div className="mt-1.5 flex items-center gap-1.5">
                            <span
                              className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                                user.plan === "start"
                                  ? "bg-white/10 text-white/60"
                                  : "bg-gold-400/15 text-gold-300"
                              }`}
                            >
                              {PLAN_NAMES[user.plan] ?? "Dima Start"}
                            </span>
                            {user.role === "admin" && (
                              <span className="flex items-center gap-1 rounded-full bg-emerald-400/15 px-2 py-0.5 text-[10px] font-bold text-emerald-300">
                                <ShieldCheck className="h-3 w-3" /> Admin
                              </span>
                            )}
                          </div>
                          <div className="mt-2 flex items-center justify-between rounded-lg bg-black/25 px-2.5 py-2 text-xs">
                            <span className="text-white/45">Sayt balansi</span>
                            <span className="font-bold text-gold-300">
                              {(user.balanceSoms ?? 0).toLocaleString("uz-UZ")} so'm
                            </span>
                          </div>
                        </div>
                        {user.role === "admin" && (
                          <button
                            onClick={() => {
                              setUserMenuOpen(false);
                              setView("admin");
                            }}
                            className="gold-focus flex w-full items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-left text-sm font-semibold text-emerald-300 transition hover:bg-emerald-400/10"
                          >
                            <ShieldCheck className="h-4 w-4" />
                            Admin panel
                          </button>
                        )}
                        {user.plan === "start" && (
                          <button
                            onClick={() => {
                              setUserMenuOpen(false);
                              setView("pricing");
                            }}
                            className="gold-focus flex w-full items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-left text-sm font-semibold text-gold-300 transition hover:bg-gold-400/10"
                          >
                            <Crown className="h-4 w-4" />
                            Premium'ga o'tish
                          </button>
                        )}
                        <button
                          onClick={logout}
                          className="gold-focus flex w-full items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-left text-sm font-semibold text-white/70 transition hover:bg-white/[0.06] hover:text-white"
                        >
                          <LogOut className="h-4 w-4" />
                          Chiqish
                        </button>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Asosiy maydon */}
      <main className="relative z-10 flex min-h-0 flex-1 flex-col pb-[72px] md:pb-0">
        <AnimatePresence mode="wait">
          <motion.div
            key={view}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.28, ease: "easeOut" }}
            className="flex min-h-0 flex-1 flex-col"
          >
            {view === "chat" && (
              <ChatPanel user={user} onPricing={() => setView("pricing")} />
            )}
            {view === "image" && <ImageStudio />}
            {view === "slides" && <DocumentStudio initialKind="slides" />}
            {view === "report" && <DocumentStudio initialKind="report" />}
            {view === "pricing" && <PricingView currentPlan={user?.plan} />}
            {view === "admin" && isAdmin && <AdminPanel />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Mobil pastki navigatsiya (Android uchun qulay) */}
      <nav className="fixed bottom-0 left-0 right-0 z-20 border-t border-white/[0.07] bg-ink-950/85 backdrop-blur-xl md:hidden">
        <div className="mx-auto flex max-w-lg items-stretch gap-1 overflow-x-auto px-2 pb-[env(safe-area-inset-bottom)]">
          {NAV.map((n) => {
            const Icon = n.icon;
            const on = view === n.id;
            return (
              <button
                key={n.id}
                onClick={() => setView(n.id)}
                className="gold-focus relative flex min-w-[64px] flex-1 flex-col items-center gap-1 py-2.5"
              >
                {on && (
                  <motion.span
                    layoutId="mobile-nav-glow"
                    className="absolute -top-px h-[2px] w-12 rounded-full bg-gradient-to-r from-gold-300 to-gold-600"
                  />
                )}
                <Icon className={`h-5 w-5 ${on ? "text-gold-400" : "text-white/45"}`} />
                <span
                  className={`text-[10px] font-bold ${on ? "text-gold-300" : "text-white/45"}`}
                >
                  {n.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      <AuthDialog open={authOpen} onClose={() => setAuthOpen(false)} onAuth={setUser} />
    </div>
  );
}
