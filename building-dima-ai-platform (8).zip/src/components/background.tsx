export default function Background() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      {/* Yuqori oltin nur */}
      <div className="absolute -top-40 left-1/2 h-[520px] w-[820px] -translate-x-1/2 rounded-full bg-[radial-gradient(ellipse_at_center,rgba(245,192,68,0.16),transparent_60%)] blur-2xl" />
      {/* Suzuvchi sharlar */}
      <div className="absolute -left-32 top-1/3 h-[420px] w-[420px] animate-float-slow rounded-full bg-[radial-gradient(circle,rgba(245,192,68,0.10),transparent_65%)] blur-3xl" />
      <div
        className="absolute -right-36 bottom-0 h-[480px] w-[480px] animate-float-slow rounded-full bg-[radial-gradient(circle,rgba(120,80,255,0.08),transparent_65%)] blur-3xl"
        style={{ animationDelay: "-7s" }}
      />
      {/* Nozik panjara */}
      <div
        className="absolute inset-0 opacity-[0.05]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px)",
          backgroundSize: "56px 56px",
          maskImage: "radial-gradient(ellipse at 50% 0%, black 30%, transparent 75%)",
          WebkitMaskImage: "radial-gradient(ellipse at 50% 0%, black 30%, transparent 75%)",
        }}
      />
    </div>
  );
}
