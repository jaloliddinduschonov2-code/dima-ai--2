export type PublicUser = {
  id: string;
  email: string;
  name: string | null;
  plan: "start" | "pro" | "turbo" | string;
  role: "user" | "admin" | string;
  balanceSoms: number;
};

export const PLAN_NAMES: Record<string, string> = {
  start: "Dima Start",
  pro: "Dima Pro",
  turbo: "Dima Turbo",
};
