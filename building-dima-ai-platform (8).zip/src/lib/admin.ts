/**
 * Admin yordamchi funksiyalari. Faqat server tomonda ishlatiladi.
 */
import { db } from "@/db";
import { users, imageGenerations, chatMessages } from "@/db/schema";
import { isAdminEmail } from "@/lib/auth";
import { count, eq, sql, desc, gte, and } from "drizzle-orm";

export type AdminStats = {
  totalUsers: number;
  premiumUsers: number;
  imagesToday: number;
  messagesToday: number;
};

export type AdminUser = {
  id: string;
  email: string;
  name: string | null;
  plan: string;
  role: string;
  balanceSoms: number;
  createdAt: string;
  imagesTotal: number;
  messagesTotal: number;
};

export async function requireAdmin() {
  // Dinamik import — chunki getCurrentUser server komponent/route da ishlatiladi
  const { getCurrentUser } = await import("@/lib/auth");
  const u = await getCurrentUser();
  if (!u) throw new Response(JSON.stringify({ error: "Kiring" }), { status: 401 });
  if (!isAdminEmail(u.email)) {
    throw new Response(JSON.stringify({ error: "Siz admin emassiz" }), { status: 403 });
  }
  return u;
}

export async function getAdminStats(): Promise<AdminStats> {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [{ total }] = await db.select({ total: count() }).from(users);
  const [{ premium }] = await db
    .select({ premium: count() })
    .from(users)
    .where(sql`${users.plan} != 'start'`);
  const [{ imagesToday }] = await db
    .select({ imagesToday: count() })
    .from(imageGenerations)
    .where(gte(imageGenerations.createdAt, today));
  const [{ messagesToday }] = await db
    .select({ messagesToday: count() })
    .from(chatMessages)
    .where(
      and(
        gte(chatMessages.createdAt, today),
        eq(chatMessages.role, "user"),
      ),
    );

  return {
    totalUsers: total,
    premiumUsers: premium,
    imagesToday,
    messagesToday,
  };
}

export async function getAdminUsers(): Promise<AdminUser[]> {
  const rows = await db
    .select({
      id: users.id,
      email: users.email,
      name: users.name,
      plan: users.plan,
      role: users.role,
      balanceSoms: users.balanceSoms,
      createdAt: users.createdAt,
    })
    .from(users)
    .orderBy(desc(users.createdAt));

  // Har bir user uchun hisoblar
  const results: AdminUser[] = await Promise.all(
    rows.map(async (r) => {
      const [{ imgCount }] = await db
        .select({ imgCount: count() })
        .from(imageGenerations)
        .where(eq(imageGenerations.userId, r.id));
      const [{ msgCount }] = await db
        .select({ msgCount: count() })
        .from(chatMessages)
        .where(and(eq(chatMessages.userId, r.id), eq(chatMessages.role, "user")));
      return {
        id: r.id,
        email: r.email,
        name: r.name,
        plan: r.plan,
        role: r.role,
        balanceSoms: r.balanceSoms,
        createdAt: r.createdAt.toISOString(),
        imagesTotal: imgCount,
        messagesTotal: msgCount,
      };
    }),
  );
  return results;
}
