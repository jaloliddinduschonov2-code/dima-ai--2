/**
 * Mijoz ko'radigan va foydalanadigan havolalar/env o'zgaruvchilari.
 * NEXT_PUBLIC_* prefiksi bilan hech qanday sirli kalit kiritilmasin.
 */

export const TELEGRAM = {
  channel: process.env.NEXT_PUBLIC_TELEGRAM_CHANNEL || "https://t.me/dima_ai_offical",
  admin: process.env.NEXT_PUBLIC_TELEGRAM_ADMIN || "https://t.me/Dima_ai_admin",
};

export const SITE = {
  name: "Dima'AI",
  url: process.env.NEXT_PUBLIC_SITE_URL || "https://dima-ai-gold.vercel.app",
};
