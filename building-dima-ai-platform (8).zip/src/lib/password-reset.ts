import { createHash, randomBytes } from "crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { passwordResetTokens } from "@/db/schema";

export function hashResetToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export async function createPasswordResetToken(userId: string) {
  // Avvalgi tokenlarni o'chiramiz — faqat oxirgisi ishlaydi.
  await db.delete(passwordResetTokens).where(eq(passwordResetTokens.userId, userId));
  const token = randomBytes(32).toString("hex");
  const tokenHash = hashResetToken(token);
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000);
  await db.insert(passwordResetTokens).values({ userId, tokenHash, expiresAt });
  return { token, expiresAt };
}

export async function sendResetEmail(opts: {
  to: string;
  name?: string | null;
  resetUrl: string;
}): Promise<boolean> {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.RESET_FROM_EMAIL;
  if (!apiKey || !from) return false;

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from,
        to: [opts.to],
        subject: "Dima'AI — parolni tiklash",
        html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;color:#171717"><h2>Dima'AI parolini tiklash</h2><p>Assalomu alaykum${opts.name ? `, ${opts.name}` : ""}.</p><p>Quyidagi tugma 30 daqiqa davomida ishlaydi:</p><p><a href="${opts.resetUrl}" style="display:inline-block;padding:12px 20px;background:#e9a520;color:#080808;border-radius:10px;text-decoration:none;font-weight:700">Yangi parol o'rnatish</a></p><p>Agar bu so'rovni siz yubormagan bo'lsangiz, xatni e'tiborsiz qoldiring.</p></div>`,
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}
