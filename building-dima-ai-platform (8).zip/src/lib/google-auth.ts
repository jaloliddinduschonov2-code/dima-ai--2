import { OAuth2Client } from "google-auth-library";

const CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;

export function googleIsConfigured() {
  return Boolean(CLIENT_ID && CLIENT_SECRET);
}

function buildClient(redirectUri: string) {
  if (!CLIENT_ID || !CLIENT_SECRET) {
    throw new Error("GOOGLE_CLIENT_ID va GOOGLE_CLIENT_SECRET hali sozlanmagan");
  }
  return new OAuth2Client(CLIENT_ID, CLIENT_SECRET, redirectUri);
}

const SCOPES = [
  "https://www.googleapis.com/auth/userinfo.email",
  "https://www.googleapis.com/auth/userinfo.profile",
  "openid",
];

export function getGoogleAuthUrl(redirectUri: string, state: string) {
  const client = buildClient(redirectUri);
  return client.generateAuthUrl({
    access_type: "online",
    scope: SCOPES,
    state,
    prompt: "select_account",
  });
}

export async function verifyGoogleCode(code: string, redirectUri: string) {
  const client = buildClient(redirectUri);
  const { tokens } = await client.getToken(code);
  const ticket = await client.verifyIdToken({
    idToken: tokens.id_token ?? "",
    audience: process.env.GOOGLE_CLIENT_ID,
  });
  const payload = ticket.getPayload();
  if (!payload || !payload.email) throw new Error("Google emailni olib bo'lmadi");
  return {
    email: payload.email.toLowerCase(),
    name: payload.name ?? null,
    picture: payload.picture ?? null,
    emailVerified: Boolean(payload.email_verified),
  };
}
