/**
 * AI provayderlar markazi.
 * Kalitlar faqat serverda — frontend hech qachon ularni olmaydi.
 */

export type ProviderId = "groq" | "openai" | "pollinations";

export type ProviderAttempt = { provider: ProviderId; model: string };

export const PROVIDERS: Record<
  string,
  {
    label: string;
    provider: ProviderId;
    model: string;
    temperature: number;
    maxTokens: number;
    multimodal?: boolean;
    /** Asosiy provayder ishlamasa (401/402/429/404) — ketma-ket sinab ko'riladigan zaxiralar */
    fallback?: ProviderAttempt[];
  }
> = {
  "gemini-pro": {
    label: "Gemini Pro",
    provider: "pollinations",
    model: "openai",
    temperature: 0.7,
    maxTokens: 4096,
    // Pollinations kalitsiz va bepul — Gemini Pro barcha foydalanuvchilar uchun.
    fallback: [{ provider: "groq", model: "llama-3.3-70b-versatile" }],
  },
  "gpt-astra-6": {
    label: "GPT Astra 6",
    provider: "openai",
    model: "gpt-4o-mini", // "GPT Astra 6" nomi orqasida haqiqiy OpenAI model
    temperature: 0.6,
    maxTokens: 4096,
    multimodal: true, // gpt-4o-mini rasmlarni ham ko'radi
    // OpenAI balansi bo'sa (hozircha), Groq yoki Pollinations o'g'ralib ishlatadi
    fallback: [
      { provider: "pollinations", model: "openai" },
      { provider: "groq", model: "llama-3.3-70b-versatile" },
    ],
  },
  "claude-opus": {
    label: "Claude Opus 5.5",
    provider: "groq",
    model: "meta-llama/llama-4-scout-17b-16e-instruct", // vision model — rasm ko'radi
    temperature: 0.4,
    maxTokens: 4096,
    multimodal: true,
    fallback: [{ provider: "pollinations", model: "openai" }],
  },
};

export type ChatId = keyof typeof PROVIDERS;

export function chatIds(): ChatId[] {
  return Object.keys(PROVIDERS) as ChatId[];
}
