import { randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import { eq, and, gt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users, type User } from "@/db/schema";

const SESSION_COOKIE = "dima_session";
const SESSION_DAYS = 30;

/**
 * Faqat shu email'lar administrator. Qo'shimcha adminlar — ADMIN_EMAILS env
 * (vergul bilan ajratilgan). Asosiy admin: ro'yxatdan o'tgan zahoti admin rolini oladi.
 */
const DEFAULT_ADMINS = ["jaloliddinduschonov2@gmail.com"];

export function adminEmails(): string[] {
  const extra = (process.env.ADMIN_EMAILS ?? "")
    .split(",")
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
  return Array.from(new Set([...DEFAULT_ADMINS.map((e) => e.toLowerCase()), ...extra]));
}

export function isAdminEmail(email: string | undefined | null): boolean {
  if (!email) return false;
  return adminEmails().includes(email.trim().toLowerCase());
}

/** Parolni xavfsiz hash qilish (scrypt). */
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  if (candidate.length !== expected.length) return false;
  return timingSafeEqual(candidate, expected);
}

export async function createSession(userId: string): Promise<void> {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(sessions).values({ id: token, userId, expiresAt });

  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_DAYS * 24 * 60 * 60,
    secure: process.env.NODE_ENV === "production",
  });
}

/** Cookie orqali joriy foydalanuvchini topish (admin rolini yangilash imkoniyati bilan). */
export async function getCurrentUser(): Promise<User | null> {
  try {
    const store = await cookies();
    const token = store.get(SESSION_COOKIE)?.value;
    if (!token) return null;

    const rows = await db
      .select({ user: users, expiresAt: sessions.expiresAt })
      .from(sessions)
      .innerJoin(users, eq(sessions.userId, users.id))
      .where(and(eq(sessions.id, token), gt(sessions.expiresAt, new Date())))
      .limit(1);

    const user = rows[0]?.user ?? null;
    if (!user) return null;

    // Agar email adminlar ro'yxatida bo'lsa-u, lekin rol hali 'user' bo'lsa — avtomatik ko'tarish
    const shouldBeAdmin = isAdminEmail(user.email);
    if (shouldBeAdmin && user.role !== "admin") {
      await db
        .update(users)
        .set({ role: "admin" })
        .where(eq(users.id, user.id));
      return { ...user, role: "admin" };
    }
    // Agar endi admin emas bo'lib qolgan bo'lsa (env o'zgardi), tushirish
    if (!shouldBeAdmin && user.role === "admin" && !DEFAULT_ADMINS.includes(user.email.toLowerCase())) {
      // Asosiy adminni tasodifan tushurib qo'ymaslik — uni o'tkazib yuboramiz
      // (env orqali qo'shilgan adminlarni olib tashlash mumkin, lekin biz hozir hech nima qilmaymiz)
    }
    return user;
  } catch {
    return null;
  }
}

export async function destroySession(): Promise<void> {
  try {
    const store = await cookies();
    const token = store.get(SESSION_COOKIE)?.value;
    if (token) {
      await db.delete(sessions).where(eq(sessions.id, token));
    }
    store.delete(SESSION_COOKIE);
  } catch {
    // cookie allaqachon o'chirilgan bo'lishi mumkin
  }
}

export function publicUser(u: User) {
  return {
    id: u.id,
    email: u.email,
    name: u.name,
    plan: u.plan,
    role: u.role,
    balanceSoms: u.balanceSoms,
  };
}
